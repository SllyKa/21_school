/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/09/06 12:11:24 by gbrandon          #+#    #+#             */
/*   Updated: 2018/09/07 11:31:27 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

#include "current_day.h"

int		main(int argc, char **argv)
{
	t_btree *node;
	node = btree_create_node("hello");
	printf("adress_node: %p\n", node);
	printf("data: %s\n", (char *)node->item);
	return (0);
}
