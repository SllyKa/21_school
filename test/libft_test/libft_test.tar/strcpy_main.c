/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_template.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 16:38:04 by gbrandon          #+#    #+#             */
/*   Updated: 2018/11/23 21:09:17 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libc.h>
#include <stdlib.h>
#include "libft.h"
#include "libextra.h"

void	s_print(char *ptr, size_t s)
{
	size_t i;

	i = 0;
	while (i < s)
	{
			printf("%c ", *ptr);
			i++;
			ptr++;
	}	
	printf("\n");
}

void    *mem_al(size_t n)
{
   void *a = malloc(n);
   return a;
}

void    mem_free(void *ptr)
{
	    free(ptr);
}

int		test_func(char *(*f)(char*, const char*),char *str1, size_t str_size, 
		char *str2, char *txt1, char *txt2)
{
	char *new_str;
	strcpy(str1, txt1);
	strcpy(str2, txt2);

	new_str = f(str1, str2);

	printf("%-15s%s\n","strcpy_res:", new_str);
	s_print(str1, str_size);
	//bits(ptr_size, ptr);

	return (0);
}

int		main(void)
{
	size_t s = 15;
	size_t s2 = 20;

	char		*(*origin_f)(char *dest, const char *str) = &strcpy;
	char		*(*handmade)(char *dest, const char *str) = &ft_strcpy;

	char *origin = (char*)mem_al(s);
	char *origin2 = (char*)mem_al(s2);

	test_func(origin_f, origin, s, origin2, "privet_chelover", "poka_men");
	test_func(handmade, origin, s, origin2, "privet_chelover", "poka_men");
	printf("\n");

	test_func(origin_f, origin, s, origin2, "", "poka_men");
	test_func(handmade, origin, s, origin2, "", "poka_men");
	printf("\n");

	test_func(origin_f, origin, s, origin2, "privet chelover", "");
	test_func(handmade, origin, s, origin2, "privet chelover", "");
	printf("\n");

	test_func(origin_f, origin, s, origin2, "h", "poka men");
	test_func(handmade, origin, s, origin2, "h", "poka men");
	printf("\n");

	test_func(origin_f, origin, s, origin2, "**()%^$\0%^#%^&", "ha");
	test_func(handmade, origin, s, origin2, "**()%^$\0%^#%^&", "ha");
	printf("\n");

	test_func(origin_f, origin, s, origin2, "\0\0\0\0\0\0", "poka humans");
	test_func(handmade, origin, s, origin2, "\0\0\0\0\0\0", "poka humans");
	printf("\n");

	test_func(origin_f, origin, s, origin2, "\0", "poka humans");
	test_func(handmade, origin, s, origin2, "\0", "poka humans");
	printf("\n");

	test_func(origin_f, origin, s, origin2, "privet chelover", "\0\0");
	test_func(handmade, origin, s, origin2, "privet chelover", "\0\0");
	printf("\n");
	return (0);
}
