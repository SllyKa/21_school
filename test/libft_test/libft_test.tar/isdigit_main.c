/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_template.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 16:38:04 by gbrandon          #+#    #+#             */
/*   Updated: 2018/11/27 16:14:20 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libc.h>
#include <stdlib.h>
#include "libft.h"
#include "libextra.h"
#include <errno.h>
#include <ctype.h>

# define TEST_NAME "isdigit_res"

void	errno_ch_and_pr(void)
{
	printf("%-15s%s: %i\n", "errno_res:", strerror(errno), errno);
	errno = 0;
}

void	s_print(char *str, size_t s)
{
	size_t i;

	i = 0;
	while (i < s)
	{
			printf("%c ", *str);
			i++;
			str++;
	}	
	printf("\n");
}

void    *mem_al(size_t n)
{
   void *a = malloc(n);
   return a;
}

void    mem_free(void *ptr)
{
	    free(ptr);
}

int     test_func(int (*f)(int c), int ch, int f_type)
{
	int	cmp_res;
	//strcpy(str1, txt1);
	//strcpy(str2, txt2);

	cmp_res = f(ch);

	if (f_type)
		printf("%-15s", "origin_res:");
	else
		printf("%-15s", "handmade_res:");
	printf("%-15s%i\n",TEST_NAME, cmp_res);
	//s_print(str1, str_size);
	//bits(ptr_size, ptr);

	return (0);
}

int		main(void)
{
	extern int errno;
	//size_t s = 50;
	//size_t s2 = 20;

	int		(*origin_f)(int c) = &isdigit;
	int		(*handmade)(int c) = &ft_isdigit;

	//void *origin = mem_al(s);
	//void *origin2 = mem_al(s2);
	
	printf("\v\v\v\v\v");
	printf("%30c%s#\n\n",'#', TEST_NAME); 

	test_func(origin_f, '\n', 1);
	test_func(handmade, '\n', 0);
	printf("\n");

	test_func(origin_f, '1', 1);
	test_func(handmade, '1', 0);
	printf("\n");

	test_func(origin_f, 'a', 1);
	test_func(handmade, 'a', 0);
	printf("\n");

	test_func(origin_f, 'z', 1);
	test_func(handmade, 'z', 0);
	printf("\n");

	test_func(origin_f, 'A', 1);
	test_func(handmade, 'A', 0);
	printf("\n");

	test_func(origin_f, 'Z', 1);
	test_func(handmade, 'Z', 0);
	printf("\n");

	test_func(origin_f, 0, 1);
	test_func(handmade, 0, 0);
	printf("\n");

	test_func(origin_f, 125, 1);
	test_func(handmade, 125, 0);
	printf("\n");

	test_func(origin_f, 'd', 1);
	test_func(handmade, 'd', 0);
	printf("\n");

	test_func(origin_f, 'C', 1);
	test_func(handmade, 'C', 0);
	printf("\n");

	test_func(origin_f, '#', 1);
	test_func(handmade, '#', 0);
	printf("\n");

	test_func(origin_f, ',', 1);
	test_func(handmade, ',', 0);
	printf("\n");
	
	test_func(origin_f, '\10', 1);
	test_func(handmade, '\10', 0);
	printf("\n");

	test_func(origin_f, '\377', 1);
	test_func(handmade, '\377', 0);
	printf("\n");

	test_func(origin_f, '\255', 1);
	test_func(handmade, '\255', 0);
	printf("\n");

	test_func(origin_f, '\122', 1);
	test_func(handmade, '\122', 0);
	printf("\n");

	test_func(origin_f, '0', 1);
	test_func(handmade, '0', 0);
	printf("\n");

	test_func(origin_f, '9', 1);
	test_func(handmade, '9', 0);
	printf("\n");

	test_func(origin_f, '/', 1);
	test_func(handmade, '/', 0);
	printf("\n");

	test_func(origin_f, ':', 1);
	test_func(handmade, ':', 0);
	printf("\n");

	test_func(origin_f, '5', 1);
	test_func(handmade, '5', 0);
	printf("\n");

	test_func(origin_f, '\64', 1);
	test_func(handmade, '\64', 0);
	printf("\n");

	test_func(origin_f, '\70', 1);
	test_func(handmade, '\70', 0);
	printf("\n");

	test_func(origin_f, 9, 1);
	test_func(handmade, 9, 0);
	printf("\n");
	
	test_func(origin_f, '\0', 1);
	test_func(handmade, '\0', 0);
	printf("\n");

	test_func(origin_f, EOF, 1);
	test_func(handmade, EOF, 0);
	printf("\n");

	test_func(origin_f, 567, 1);
	test_func(handmade, 567, 0);
	printf("\n");

	test_func(origin_f, 3000, 1);
	test_func(handmade, 3000, 0);
	printf("\n");

	test_func(origin_f, INT_MAX, 1);
	test_func(handmade, INT_MAX, 0);
	printf("\n");

	test_func(origin_f, INT_MIN, 1);
	test_func(handmade, INT_MIN, 0);
	printf("\n");

	test_func(origin_f, INT_MIN + 100, 1);
	test_func(handmade, INT_MIN + 100, 0);
	printf("\n");

	test_func(origin_f, 28540, 1);
	test_func(handmade, 28540, 0);
	printf("\n");

	test_func(origin_f, -10, 1);
	test_func(handmade, -10, 0);
	printf("\n");

	test_func(origin_f, 288, 1);
	test_func(handmade, 288, 0);
	printf("\n");
	return (0);
}
