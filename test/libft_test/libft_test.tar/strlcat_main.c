/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_template.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 16:38:04 by gbrandon          #+#    #+#             */
/*   Updated: 2018/11/28 20:00:03 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libc.h>
#include <stdlib.h>
#include "libft.h"
#include "libextra.h"

void	s_print(char *ptr, size_t s)
{
	size_t i;

	i = 0;
	while (i < s)
	{
			printf("%c ", *ptr);
			i++;
			ptr++;
	}	
	printf("\n");
}

void    *mem_al(size_t n)
{
   void *a = malloc(n);
   return a;
}

void    mem_free(void *ptr)
{
	    free(ptr);
}

int		test_func(size_t (*f)(char*, const char*, size_t n), char *str1, size_t str_size,
		        char *str2, char *txt1, char *txt2, size_t number_of_bytes, int f_type)
{
	size_t		res;
	strcpy(str1, txt1);
	strcpy(str2, txt2);

	res = str_size;
	res = f(str1, str2, number_of_bytes);

	printf("%-15s%lu\n","strlcat_res:", res);

	if (f_type)
		printf("%-15s", "origin_res:");
	else
		printf("%-15s", "handmade_res:");
	printf("str: %s\n", str1);
	//s_print(str1, str_size);
	//bits(ptr_size, ptr);

    return (0);
}

int		main(void)
{
	size_t s = 35;
	size_t s2 = 20;

	size_t		(*origin_f)(char *dest, const char *str, size_t n) = &strlcat;
	size_t		(*handmade)(char *dest, const char *str, size_t n) = &ft_strlcat;

	char *origin = (char*)mem_al(s);
	char *origin2 = (char*)mem_al(s2);

	test_func(origin_f, origin, s, origin2, "privet_chelover", "poka_men", 8, 1);
	test_func(handmade, origin, s, origin2, "privet_chelover", "poka_men", 8, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "privet_chelover", "poka_men", 15, 1);
	test_func(handmade, origin, s, origin2, "privet_chelover", "poka_men", 15, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "privet_chelover", "poka_men", 16, 1);
	test_func(handmade, origin, s, origin2, "privet_chelover", "poka_men", 16, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "privet_chelover", "poka_men", 14, 1);
	test_func(handmade, origin, s, origin2, "privet_chelover", "poka_men", 14, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "privet_chelover", "poka_men", 7, 1);
	test_func(handmade, origin, s, origin2, "privet_chelover", "poka_men", 7, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "privet_chelover", "poka_men", 9, 1);
	test_func(handmade, origin, s, origin2, "privet_chelover", "poka_men", 9, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "privet_chelover", "poka_men", 0, 1);
	test_func(handmade, origin, s, origin2, "privet_chelover", "poka_men", 0, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "privet_chelover", "poka_men", 3, 1);
	test_func(handmade, origin, s, origin2, "privet_chelover", "poka_men", 3, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "privet_chelover", "poka_men", 30, 1);
	test_func(handmade, origin, s, origin2, "privet_chelover", "poka_men", 30, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "", "poka_men", 2, 1);
	test_func(handmade, origin, s, origin2, "", "poka_men", 2, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "privet chelover", "", 1, 1);
	test_func(handmade, origin, s, origin2, "privet chelover", "", 1, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "privet chelover\0p", "", 18, 1);
	test_func(handmade, origin, s, origin2, "privet chelover\0p", "", 18, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "h", "poka men", 6, 1);
	test_func(handmade, origin, s, origin2, "h", "poka men", 6, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "**()%^$\0%^#%^&", "ha", 2, 1);
	test_func(handmade, origin, s, origin2, "**()%^$\0%^#%^&", "ha", 2, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "\0\0\0\0\0\0", "poka humans", 6, 1);
	test_func(handmade, origin, s, origin2, "\0\0\0\0\0\0", "poka humans", 6, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "\0", "poka humans", 7, 1);
	test_func(handmade, origin, s, origin2, "\0", "poka humans", 7, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "privet chelover", "\0\0", 2, 1);
	test_func(handmade, origin, s, origin2, "privet chelover", "\0\0", 2, 0);
	printf("\n");

	//test_func(origin_f, NULL, s, origin2, "privet chelover", "\0\0", 2, 1);
	//test_func(handmade, NULL, s, origin2, "privet chelover", "\0\0", 2, 0);
	//printf("\n");

	//test_func(origin_f, origin, s, NULL, "privet chelover", "\0\0", 2, 1);
	//test_func(handmade, origin, s, NULL, "privet chelover", "\0\0", 2, 0);
	//printf("\n");
	
	return (0);
}
