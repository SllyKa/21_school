/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_template.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 16:38:04 by gbrandon          #+#    #+#             */
/*   Updated: 2018/11/29 16:55:02 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libc.h>
#include <stdlib.h>
#include "libft.h"
#include "libextra.h"
#include <errno.h>
#include <ctype.h>
#include <limits.h>

# define TEST_NAME "strtrim_res"

void	s_print(char *ptr, size_t s)
{
	size_t i;

	i = 0;
	while (i < s)
	{
			printf("%c ", *ptr);
			i++;
			ptr++;
	}	
	printf("\n");
}

void    *mem_al(size_t n)
{
   void *a = malloc(n);
   return a;
}

void    mem_free(void *ptr)
{
	    free(ptr);
}

int		test_func(char *(*f)(const char*),char *str1, size_t str_size, 
		char *txt1, int f_type)
{
	char *temp_res;
	strcpy(str1, txt1);
	//strcpy(str2, txt2);

	temp_res = f(str1);
	printf("%-15s|%s|\n",TEST_NAME, temp_res);
	if (f_type)
		printf("%-15s", "origin_res:");
	else
		printf("%-15s", "handmade_res:");

	s_print(str1, str_size);
	//bits(ptr_size, ptr);

	return (0);
}

int		main(void)
{
	size_t s = 15;
	//size_t s2 = 20;

	//char		*(*origin_f)(char *dest, const char *str) = &strcat;
	char		*(*handmade)(const char *str) = &ft_strtrim;

	char *origin = (char*)mem_al(s);
	//char *origin2 = (char*)mem_al(s2);

	printf("\v\v\v\v\v");
	printf("%30c%s#\n\n",'#', TEST_NAME); 

	test_func(handmade, origin, s,"privet_chelover", 0);
	printf("\n");

	test_func(handmade, origin, s, "", 0);
	printf("\n");

	test_func(handmade, origin, s, "     p r i v e t chelover", 0);
	printf("\n");

	test_func(handmade, origin, s, "privet chel o v er    ", 0);
	printf("\n");

	test_func(handmade, origin, s, "**()%       ^$\0%^#%^&", 0);
	printf("\n");

	test_func(handmade, origin, s," \0 \0 \0 \0 \0 \0", 0);
	printf("\n");

	test_func(handmade, origin, s, "\0", 0);
	printf("\n");

	test_func(handmade, origin, s, "p          rivet chelover", 0);
	printf("\n");

	test_func(handmade, origin, s, "pr i v e t               c h e l o v e r                   !", 0);
	printf("\n");

	test_func(handmade, origin, s, "pr i v e t               c h e l o v e r                   ", 0);
	printf("\n");

	test_func(handmade, origin, s, "\n\n\n\n\na\r\r\r\t\t\ta\n\n\t   \n \t        !", 0);
	printf("\n");

	test_func(handmade, origin, s, "\n\n\n\n\na\r\r\r\t\t\ta\n\n\t   \n \t        \0", 0);
	printf("\n");

	test_func(handmade, origin, s, "p          r\ti\tv\tet c\thel\no ver ", 0);
	printf("\n");

	test_func(handmade, origin, s, " p          r\ti\tv\tet c\thel\no ver", 0);
	printf("\n");

	test_func(handmade, origin, s, " p          r\ti\tv\tet c\thel\no ver ", 0);
	printf("\n");
	
	test_func(handmade, origin, s, "                                      ", 0);
	printf("\n");

	test_func(handmade, origin, s, "     \t\n\t\t\n              \t \n          \n\n\n", 0);
	printf("\n");

	test_func(handmade, origin, s, "                        \t\t\n              @", 0);
	printf("\n");
	return (0);
}
