/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_template.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 16:38:04 by gbrandon          #+#    #+#             */
/*   Updated: 2018/12/04 16:37:34 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libc.h>
#include <stdlib.h>
#include "libft.h"
#include "libextra.h"
#include <errno.h>
#include <ctype.h>
#include <limits.h>

# define TEST_NAME "memalloc_res"

void	errno_ch_and_pr(void)
{
	printf("%-15s%s: %i\n", "errno_res:", strerror(errno), errno);
	errno = 0;
}

void	s_print(void *ptr, size_t s)
{
	size_t i;

	i = 0;
	while (i < s)
	{
			printf("%c ", *((char*)ptr));
			i++;
			ptr++;
	}	
	printf("\n");
}

void    *mem_al(size_t n)
{
   void *a = malloc(n);
   return a;
}

void    mem_free(void *ptr)
{
	    free(ptr);
}

int     test_func(void *(*f)(size_t s), size_t size_s, char *txt1, int f_type)
{
	void	*ptr;
	size_t	size;

	//strcpy(str2, txt2);

	ptr = f(size_s);

	if (f_type)
		printf("%-15s", "origin_res:");
	else
		printf("%-15s", "handmade_res:");
	printf("%-15s%p\n",TEST_NAME, ptr);

	size = size_s;
	if (size_s > 100)
		size = 20;
	if (!ptr)
		return (0);
	s_print(ptr, size);
	bits(size, ptr);
	printf("\n");

	strcpy(ptr, txt1);

	s_print(ptr, size);
	bits(size, ptr);
	printf("\n");
	return (0);
}

int		main(void)
{
	extern int errno;
	//size_t s = 50;
	//size_t s2 = 20;

	void	*(*origin_f)(size_t c) = &malloc;
	void	*(*handmade)(size_t c) = &ft_memalloc;

	//void *origin = mem_al(s);
	//void *origin2 = mem_al(s2);

	printf("\v\v\v\v\v");
	printf("%30c%s#\n\n",'#', TEST_NAME); 

	test_func(origin_f, 0, "hello!", 1);
	test_func(handmade, 0, "hello!", 0);	
	printf("\n");

	test_func(origin_f, -999999999, "heo!", 1);
	test_func(handmade, -999999999, "heo!", 0);	
	printf("\n");

	test_func(origin_f, 10, "heo!", 1);
	test_func(handmade, 10, "heo!", 0);	
	printf("\n");

	test_func(origin_f, 10, "heo!heo!heo!heo!heo!", 1);
	test_func(handmade, 10, "heo!heo!heo!heo!heo!", 0);	
	printf("\n");

	test_func(origin_f, 1000, "heo!heo!heo!heo!heo!", 1);
	test_func(handmade, 1000, "heo!heo!heo!heo!heo!", 0);	
	printf("\n");

	test_func(origin_f, 100000, "heo!heo!heo!heo!heo!", 1);
	test_func(handmade, 100000, "heo!heo!heo!heo!heo!", 0);	
	printf("\n");

	test_func(origin_f, 1000000, "heo!heo!heo!heo!heo!", 1);
	test_func(handmade, 1000000, "heo!heo!heo!heo!heo!", 0);	
	printf("\n");
	return (0);
}
