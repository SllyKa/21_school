/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_template.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 16:38:04 by gbrandon          #+#    #+#             */
/*   Updated: 2018/11/30 12:18:14 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libc.h>
#include <stdlib.h>
#include "libft.h"
#include "libextra.h"
void    s_print(void *ptr, size_t s)
{
    int i;

    i = 0;
    while (i < s)
    {
         printf("%c ", *((char*)ptr));
         i++;
         ptr++;
    }
}

void    *mem_al(size_t n)
{
	void *a = malloc(n);
	return a;
}

void    mem_free(void *ptr)
{
	    free(ptr);
}

int		test_func(void)
{
	return (0);
}

int		main(void)
{
	return (0);
}
