/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   libextra.h                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 16:13:51 by gbrandon          #+#    #+#             */
/*   Updated: 2018/11/21 16:15:27 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef LIBEXTRA_H
# define LIBEXTRA_H
# include <string.h>

void		bits(size_t, void *ptr);

#endif
