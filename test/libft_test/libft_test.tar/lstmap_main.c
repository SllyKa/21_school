/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_template.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 16:38:04 by gbrandon          #+#    #+#             */
/*   Updated: 2018/12/06 10:24:31 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libc.h>
#include <stdlib.h>
#include "libft.h"
#include "libextra.h"
#include <errno.h>
#include <ctype.h>
#include <limits.h>

# define TEST_NAME "itoa_res"

t_list		*map_list_func(t_list *elem)
{
	if (elem->content_size < 7)
		return (elem);
	return (NULL);
}

void	iter_list_func(t_list *elem)
{
	elem->content = (void*)ft_strcat(elem->content, "i was here");
	elem->content_size = ft_strlen(elem->content + 1);
}

void	del_func(void *ty, size_t size)
{
	size = 5;
	free(ty);	
}

void	print_tab(char **tab)
{
	while(*tab)
	{
		printf("|%s|\n", *tab);
		tab++;
	}
}

void	list_print(t_list *list)
{
	while (list)
	{
		printf("%-20s%s%s\n", "content", " -> ", (char*)list->content);
		printf("%-20s%s%lu\n", "content_size:" , " -> ", list->content_size);
		printf("%-20s%s%p\n", "next", " -> ", list->next);
		list = list->next;
	}
}

void	s_print(char *ptr, size_t s)
{
	size_t i;

	i = 0;
	while (i < s)
	{
			printf("%c ", *ptr);
			i++;
			ptr++;
	}	
	printf("\n");
}

void    *mem_al(size_t n)
{
   void *a = malloc(n);
   return a;
}

void    mem_free(void *ptr)
{
	    free(ptr);
}

t_list	*test_func(t_list *(*f)(void const*, size_t),
		void const *content, size_t content_size, char *txt1, int f_type)
{
	t_list *temp_res;

	strcpy((char*)content, txt1);
	//strcpy(str2, txt2);

	temp_res = f(content, content_size);
	//printf("source_str: %s\n", str1);
	//printf("%-15s|%s|\n",TEST_NAME, temp_res);
	if (f_type)
		printf("%-15s\n", "origin_res:");
	else
		printf("%-15s\n", "handmade_res:");
	list_print(temp_res);
	//print_tab(temp_res);
	//s_print(str1, str_size);
	//bits(ptr_size, ptr);

	return (temp_res);
}

int		main(void)
{
	size_t s = 35;
	//size_t s2 = 20;

	//char		*(*origin_f)(char *dest, const char *str) = &strcat;
	t_list			*(*handmade)(void const*, size_t) = &ft_lstnew;

	char *origin = (char*)mem_al(s);
	//char *origin2 = (char*)mem_al(s2);
	t_list *head = NULL;
	t_list *cur = NULL;

	printf("\v\v\v\v\v");
	printf("%30c%s#\n\n",'#', TEST_NAME); 

	cur = test_func(handmade, origin, 7, "hello!",  0);
	ft_lstadd(&head, cur);
	printf("\n");

	origin = (char*)mem_al(s);
	cur = test_func(handmade, origin, 6, "poka@",  0);
	ft_lstadd(&head, cur);
	printf("\n");

	origin = (char*)mem_al(s);
	cur = test_func(handmade, origin, 6, "senya",  0);
	ft_lstadd(&head, cur);
	printf("\n");

	origin = (char*)mem_al(s);
	cur = test_func(handmade, origin, 2, "$",  0);
	ft_lstadd(&head, cur);
	printf("\n");

	origin = (char*)mem_al(s);
	cur = test_func(handmade, origin, 1, "",  0);
	ft_lstadd(&head, cur);
	printf("\n");

	origin = (char*)mem_al(s);
	cur = test_func(handmade, origin, 8, "Thorrin",  0);
	ft_lstadd(&head, cur);
	printf("\n");

	head = ft_lstmap(head, &map_list_func);

	//ft_lstiter(head, &iter_list_func);

	//ft_lstdelone(&cur, &del_func);
	//printf("?NULL:%p\n", cur);

	//ft_lstdel(&(head->next), &del_func);
	list_print(head);
	return (0);
}
