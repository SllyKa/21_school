/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/09/06 12:11:24 by gbrandon          #+#    #+#             */
/*   Updated: 2018/12/06 15:01:49 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

#include "libft.h"

int		cmp(void *a, void *b)
{
	return (*((int*)a) - *((int*)b));
}

void	print_n(void *a)
{
	printf("number: %d\n", *((int*)a));
}

void	print_s(void *s)
{
	printf("string: %s\n", (char*)s);
}

int		main(void)
{
	t_btree *node;
	int k = 100;
	node = ft_treenew(&k);

	printf("		*** 00 ***			\n\n");

	printf("adress_node: %p\n", node);
	printf("data: %s\n\n", (char *)node->item);
	
	t_btree *node_add = NULL;
	int a[10] = {4, 10, 11, 208, 56, 4, 23, 0, 9, 1};
	//char chars[4][255] = {{"hello"}, {"aaaaa"}, {"pupppa"}, {"comon"}, {"bubble"}};
	int i = 0;
	while (i < 10)
	{
		ft_tradd(&node_add, &a[i], &cmp);
		//btree_insert_data(&node_add, &chars[i], &ft_strcmp);
		i++;
	}

	printf("		*** 01 - 04 ***		\n\n");

	printf("go_prefix_traversal:\n");
	ft_trprefix(node_add, &print_n);
	printf("\n");
	printf("go_infix_traversal:\n");
	ft_trinfix(node_add, &print_n);
	printf("\n");
	printf("go_suffix_traversal:\n");
	ft_trpostfix(node_add, &print_n);
	printf("\n\n");

	/*printf("		*** 05 ***			\n\n");
	
	t_btree *node05 = node_add;
	int th = 208;
	void *point;
	point = btree_search_item(node05, &th, &cmp);
	printf("Search result: %d\n", *((int*)point));
	printf("\n");

	printf("		*** 06 ***			\n\n");

	t_btree *node06 = node_add;
	int		count_branch;
	count_branch = btree_level_count(node06);
	printf("length_branch: %d\n", count_branch);
	printf("\n");
	*/
	return (0);
}
