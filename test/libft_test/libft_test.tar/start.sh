#!/bin/bash

make test > 2
make clean
awk '{getline x<"2"; print $0"\n"x}' 1 > 3
vi 3
