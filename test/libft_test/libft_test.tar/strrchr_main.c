/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_template.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 16:38:04 by gbrandon          #+#    #+#             */
/*   Updated: 2018/11/28 10:43:30 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libc.h>
#include <stdlib.h>
#include "libft.h"
#include "libextra.h"

void	s_print(char *str, size_t s)
{
	size_t i;

	i = 0;
	while (i < s)
	{
			printf("%c ", *str);
			i++;
			str++;
	}	
	printf("\n");
}

void    *mem_al(size_t n)
{
   void *a = malloc(n);
   return a;
}

void    mem_free(void *ptr)
{
	    free(ptr);
}

int     test_func(char *(*f)(const char*, int c), char *str1, size_t str_size,
		                 char *txt1, int c, int f_type)
{
	char	*new_str;
	strcpy(str1, txt1);
	//strcpy(str2, txt2);

	new_str = f(str1, c);
	printf("%-15s%s\n","strchr_res:", new_str);

	if (f_type)
		printf("%-15s", "origin_res:");
	else
		printf("%-15s", "handmade_res:");
	s_print(str1, str_size);
	//bits(ptr_size, ptr);

	return (0);
}

int		main(void)
{
	size_t s = 15;
	//size_t s2 = 20;

	char	*(*origin_f)(const char *dst, int c) = &strrchr;
	char	*(*handmade)(const char *dst, int c) = &ft_strrchr;

	void *origin = mem_al(s);
	//void *origin2 = mem_al(s2);

	test_func(origin_f, origin, s, "privetk_chelokver", 'k', 1);
	test_func(handmade, origin, s, "privetk_chelokver", 'k', 0);
	printf("\n");

	test_func(origin_f, origin, s, "privet_chenlovern", 'n', 1);
	test_func(handmade, origin, s, "privet_chenlovern", 'n', 0);
	printf("\n");
	
	test_func(origin_f, origin, s, "privetn_chelonver", 'n', 1);
	test_func(handmade, origin, s, "privetn_chelonver", 'n', 0);
	printf("\n");

	test_func(origin_f, origin, s, "privet_nchenlover", 'n', 1);
	test_func(handmade, origin, s, "privet_nchenlover", 'n', 0);
	printf("\n");

	test_func(origin_f, origin, s, "\0", '\0', 1);
	test_func(handmade, origin, s, "\0", '\0', 0);
	printf("\n");

	test_func(origin_f, origin, s, "men\0_opa", '\0', 1);
	test_func(handmade, origin, s, "men\0_opa", '\0', 0);
	printf("\n");

	test_func(origin_f, origin, s, "topazzz\0", '\0', 1);
	test_func(handmade, origin, s, "topazzz\0", '\0', 0);
	printf("\n");

	test_func(origin_f, origin, s, "topa\0zzz\0", 'z', 1);
	test_func(handmade, origin, s, "topa\0zzz\0", 'z', 0);
	printf("\n");

	test_func(origin_f, origin, s, "privet_nnnchennnnlover", 'n', 1);
	test_func(handmade, origin, s, "privet_nnnchennnnlover", 'n', 0);
	printf("\n");

	test_func(origin_f, origin, s, "mmmmmmmnmnmnmnnn", 'n', 1);
	test_func(handmade, origin, s, "mmmmmmmnmnmnmnnn", 'n', 0);
	printf("\n");

	test_func(origin_f, origin, s, "aaaaaaaaaa", 'a', 1);
	test_func(handmade, origin, s, "aaaaaaaaaa", 'a', 0);
	printf("\n");

	//test_func(origin_f, NULL, s, origin2, 0, "privet_chelover", "poka_men");
	//test_func(handmade, NULL, s, origin2, 0, "privet_chelover", "poka_men");
	//printf("\n");

	test_func(origin_f, origin, s, "prizvet_cheloverz", 'z', 1);
	test_func(handmade, origin, s, "prizvet_cheloverz", 'z', 0);
	printf("\n");

	//test_func(origin_f, origin, s, origin2, -10, "privet_chelover", "poka_men");
	//test_func(handmade, origin, s, origin2, -10, "privet_chelover", "poka_men");
	//printf("\n");
	
	test_func(origin_f, origin, s, "privet_chelover", 'p', 1);
	test_func(handmade, origin, s, "privet_chelover", 'p', 0);
	printf("\n");
	
	test_func(origin_f, origin, s, "privet_chelover", 61, 1);
	test_func(handmade, origin, s, "privet_chelover", 61, 0);
	printf("\n");

	test_func(origin_f, origin, s, "pr=ivet===_chelover", 61, 1);
	test_func(handmade, origin, s, "pr=ivet===_chelover", 61, 0);
	printf("\n");

	test_func(origin_f, origin, s, "*privet_chelover", 42, 1);
	test_func(handmade, origin, s, "*privet_chelover", 42, 0);
	printf("\n");

	test_func(origin_f, origin, s, "*privet_chelover*", 42, 1);
	test_func(handmade, origin, s, "*privet_chelover*", 42, 0);
	printf("\n");

	test_func(origin_f, origin, s, "privet\377_chelover", 255, 1);
	test_func(handmade, origin, s, "privet\377_chelover", 255, 0);
	printf("\n");

	test_func(origin_f, origin, s, "privet\377_chelover\254", 172, 1);
	test_func(handmade, origin, s, "privet\377_chelover\254", 172, 0);
	printf("\n");

	test_func(origin_f, origin, s, "pr\177i\177vet\377_chelover\254", 127, 1);
	test_func(handmade, origin, s, "pr\177i\177vet\377_chelover\254", 127, 0);
	printf("\n");

	test_func(origin_f, origin, s, "\\privet_chelover", 2896732, 1);
	test_func(handmade, origin, s, "\\privet_chelover", 2896732, 0);
	printf("\n");

	test_func(origin_f, origin, s, "privet_cheloveri\\", 2896732, 1);
	test_func(handmade, origin, s, "privet_chelover\\", 2896732, 0);
	printf("\n");

	test_func(origin_f, origin, s, "privet_chel)over", INT_MIN + 553, 1);
	test_func(handmade, origin, s, "privet_chel)over", INT_MIN + 553, 0);
	printf("\n");

	test_func(origin_f, origin, s, "privet_chelover", INT_MAX, 1);
	test_func(handmade, origin, s, "privet_chelover", INT_MAX, 0);
	printf("\n");

	test_func(origin_f, origin, s, "privet_chelover", INT_MIN, 1);
	test_func(handmade, origin, s, "privet_chelover", INT_MIN, 0);
	printf("\n");
	return (0);
}
