/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_template.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 16:38:04 by gbrandon          #+#    #+#             */
/*   Updated: 2018/12/06 17:00:47 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libc.h>
#include <stdlib.h>
#include "libft.h"
#include "libextra.h"
#include <limits.h>

void	s_print(void *ptr, size_t s)
{
	size_t i;

	i = 0;
	while (i < s)
	{
			printf("%c ", *((char*)ptr));
			i++;
			ptr++;
	}	
	printf("\n");
}

void    *mem_al(size_t n)
{
   void *a = malloc(n);
   return a;
}

void    mem_free(void *ptr)
{
	    free(ptr);
}

int		test_func(void	*(*f)(void*, const void*, int c, size_t n), void *ptr, size_t ptr_size, void *ptr2,
		size_t number_of_bytes, char *str1, char* str2, int c)
{
	void *temp_ptr;
	strcpy((char*)ptr, str1);
	strcpy((char*)ptr2, str2);

	temp_ptr = f(ptr, ptr2, c, number_of_bytes);

	if (temp_ptr)
		s_print(temp_ptr, ptr_size);
	s_print(ptr, ptr_size);
	bits(ptr_size, ptr);
	printf("\n");

	return (0);
}

int		main(void)
{
	size_t s = 15;
	size_t s2 = 20;

	void	*(*origin_f)(void *dst, const void *src, int c, size_t n) = &memccpy;
	void	*(*handmade)(void *dst, const void *src, int c, size_t n) = &ft_memccpy;

	void *origin = mem_al(s);
	void *origin2 = mem_al(s2);

	test_func(origin_f, origin, s, origin2, 10, "privet_chelover", "poka_men", 'k');
	test_func(handmade, origin, s, origin2, 10, "privet_chelover", "poka_men", 'k');
	printf("\n");

	test_func(origin_f, origin, s, origin2, 0, "privet_chelover", "poka_men", 'n');
	test_func(handmade, origin, s, origin2, 0, "privet_chelover", "poka_men", 'n');
	printf("\n");
	
	test_func(origin_f, origin, s, origin2, 5, "privet_chelover", "poka_men", 'n');
	test_func(handmade, origin, s, origin2, 5, "privet_chelover", "poka_men", 'n');
	printf("\n");

	test_func(origin_f, origin, s, origin2, 8, "privet_chelover", "poka_men", 'n');
	test_func(handmade, origin, s, origin2, 8, "privet_chelover", "poka_men", 'n');
	printf("\n");

	//test_func(origin_f, NULL, s, origin2, 0, "privet_chelover", "poka_men");
	//test_func(handmade, NULL, s, origin2, 0, "privet_chelover", "poka_men");
	//printf("\n");

	test_func(origin_f, origin, s, origin2, 120, "privet_chelover", "poka_men_and_all_other_humansz", 'z');
	test_func(handmade, origin, s, origin2, 120, "privet_chelover", "poka_men_and_all_other_humansz", 'z');
	printf("\n");

	//test_func(origin_f, origin, s, origin2, -10, "privet_chelover", "poka_men");
	//test_func(handmade, origin, s, origin2, -10, "privet_chelover", "poka_men");
	//printf("\n");
	
	test_func(origin_f, origin, s, origin2, 14, "privet_chelover", "poka_men", 'p');
	test_func(handmade, origin, s, origin2, 14, "privet_chelover", "poka_men", 'p');
	printf("\n");
	
	test_func(origin_f, origin, s, origin2, 14, "privet_chelover", "poka_men", 61);
	test_func(handmade, origin, s, origin2, 14, "privet_chelover", "poka_men", 61);
	printf("\n");

	test_func(origin_f, origin, s, origin2, 14, "privet_chelover", "pok=a_men", 61);
	test_func(handmade, origin, s, origin2, 14, "privet_chelover", "pok=a_men", 61);
	printf("\n");

	test_func(origin_f, origin, s, origin2, 14, "*privet_chelover", "poka_men", 42);
	test_func(handmade, origin, s, origin2, 14, "*privet_chelover", "poka_men", 42);
	printf("\n");

	test_func(origin_f, origin, s, origin2, 14, "privet_chelover", "pok\377a_men", 255);
	test_func(handmade, origin, s, origin2, 14, "privet_chelover", "pok\377a_men", 255);
	printf("\n");

	test_func(origin_f, origin, s, origin2, 14, "privet_chelover", "po\\ka_men", 2896732);
	test_func(handmade, origin, s, origin2, 14, "privet_chelover", "po\\ka_men", 2896732);
	printf("\n");

	test_func(origin_f, origin, s, origin2, 14, "privet_chelover", "po/ka_me)n", INT_MIN + 553);
	test_func(handmade, origin, s, origin2, 14, "privet_chelover", "po/ka_me)n", INT_MIN + 553);
	printf("\n");

	test_func(origin_f, origin, s, origin2, 14, "privet_chelover", "poka_men", INT_MAX);
	test_func(handmade, origin, s, origin2, 14, "privet_chelover", "poka_men", INT_MAX);
	printf("\n");

	test_func(origin_f, origin, s, origin2, 14, "privet_chelover", "poka_men", INT_MIN);
	test_func(handmade, origin, s, origin2, 14, "privet_chelover", "poka_men", INT_MIN);
	printf("\n");

	//printf("pointer: %p\n", origin_f(NULL, NULL, 5, 10));
	//printf("pointer: %p\n", handmade(NULL, NULL, 5, 10));
	return (0);
}
