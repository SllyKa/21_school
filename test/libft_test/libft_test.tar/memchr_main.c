/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_template.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 16:38:04 by gbrandon          #+#    #+#             */
/*   Updated: 2018/11/27 17:14:31 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libc.h>
#include <stdlib.h>
#include "libft.h"
#include "libextra.h"
#include <limits.h>

void	s_print(void *ptr, size_t s)
{
	size_t i;

	i = 0;
	while (i < s)
	{
			printf("%c ", *((char*)ptr));
			i++;
			ptr++;
	}	
	printf("\n");
}

void    *mem_al(size_t n)
{
   void *a = malloc(n);
   return a;
}

void    mem_free(void *ptr)
{
	    free(ptr);
}

int		test_func(void	*(*f)(const void*, int c, size_t n), void *ptr, size_t ptr_size, 
		size_t number_of_bytes, char *str1, int c)
{
	void *temp_ptr;
	strcpy((char*)ptr, str1);

	temp_ptr = f(ptr, c, number_of_bytes);

	if (temp_ptr)
		s_print(temp_ptr, ptr_size);
	s_print(ptr, ptr_size);
	bits(ptr_size, ptr);
	printf("\n");

	return (0);
}

int		main(void)
{
	size_t s = 15;
	//size_t s2 = 20;

	void	*(*origin_f)(const void *dst, int c, size_t n) = &memchr;
	void	*(*handmade)(const void *dst, int c, size_t n) = &ft_memchr;

	void *origin = mem_al(s);
	//void *origin2 = mem_al(s2);

	test_func(origin_f, origin, s, 10, "privetk_chelover", 'k');
	test_func(handmade, origin, s, 10, "privetk_chelover", 'k');
	printf("\n");

	test_func(origin_f, origin, s, 0, "privet_chenlover", 'n');
	test_func(handmade, origin, s, 0, "privet_chenlover", 'n');
	printf("\n");
	
	test_func(origin_f, origin, s, 5, "privet_chelonver", 'n');
	test_func(handmade, origin, s, 5, "privet_chelonver", 'n');
	printf("\n");

	test_func(origin_f, origin, s, 7, "privet_nchelover", 'n');
	test_func(handmade, origin, s, 7, "privet_nchelover", 'n');
	printf("\n");

	test_func(origin_f, origin, s, 8, "privet_nchelover", 'n');
	test_func(handmade, origin, s, 8, "privet_nchelover", 'n');
	printf("\n");

	//test_func(origin_f, NULL, s, origin2, 0, "privet_chelover", "poka_men");
	//test_func(handmade, NULL, s, origin2, 0, "privet_chelover", "poka_men");
	//printf("\n");

	test_func(origin_f, origin, s, 120, "privet_cheloverz", 'z');
	test_func(handmade, origin, s, 120, "privet_cheloverz", 'z');
	printf("\n");

	//test_func(origin_f, origin, s, origin2, -10, "privet_chelover", "poka_men");
	//test_func(handmade, origin, s, origin2, -10, "privet_chelover", "poka_men");
	//printf("\n");
	
	test_func(origin_f, origin, s, 14, "privet_chelover", 'p');
	test_func(handmade, origin, s, 14, "privet_chelover", 'p');
	printf("\n");
	
	test_func(origin_f, origin, s, 14, "privet_chelover", 61);
	test_func(handmade, origin, s, 14, "privet_chelover", 61);
	printf("\n");

	test_func(origin_f, origin, s, 14, "privet=_chelover", 61);
	test_func(handmade, origin, s, 14, "privet=_chelover", 61);
	printf("\n");

	test_func(origin_f, origin, s, 14, "*privet_chelover", 42);
	test_func(handmade, origin, s, 14, "*privet_chelover", 42);
	printf("\n");

	test_func(origin_f, origin, s, 14, "privet\377_chelover", 255);
	test_func(handmade, origin, s, 14, "privet\377_chelover", 255);
	printf("\n");

	test_func(origin_f, origin, s, 14, "privet\377_chelover", INT_MAX);
	test_func(handmade, origin, s, 14, "privet\377_chelover", INT_MAX);
	printf("\n");

	test_func(origin_f, origin, s, 14, "privet\377_chelover", INT_MIN);
	test_func(handmade, origin, s, 14, "privet\377_chelover", INT_MIN);
	printf("\n");

	test_func(origin_f, origin, s, 14, "privet]_chelover", 2896733);
	test_func(handmade, origin, s, 14, "privet]_chelover", 2896733);
	printf("\n");
	
	test_func(origin_f, origin, s, 15, "!privet_chelover", INT_MIN + 289);
	test_func(handmade, origin, s, 14, "!privet_chelover", INT_MIN + 289);
	printf("\n");
	return (0);
}
