/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_template.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 16:38:04 by gbrandon          #+#    #+#             */
/*   Updated: 2018/11/22 15:41:52 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libc.h>
#include <stdlib.h>
#include <string.h>
#include "libft.h"
#include "libextra.h"

int		test_func(void (*f)(void *s, size_t n), void *src, size_t src_size, char *str, size_t size, int res)
{
	size_t i;
	void *start_src = src;

	i = 0;
	strcpy((char*)src, str);
	f(src, size);
	if (res)
		printf("%-15s","origin_res:");
	else
		printf("%-15s", "handmade_res:");
	
	while (i < src_size)
	{
		printf("%c", *((char*)src));
		i++;
		src++;
	}
	printf("\n");
	src = start_src;
	bits(src_size, src);
	printf("\n");
	return (0);
}

void	*mem_al(size_t n)
{
	void *a = malloc(n);
	return a;
}

void	mem_free(void *ptr)
{
	free(ptr);
}

int		main(void)
{
	int size = 15;
	void *origin = malloc(size);
	void *handmade = malloc(size);

	void (*origin_f)(void *, size_t) = &bzero;
	void (*handmade_f)(void *, size_t) = &ft_bzero;

	test_func(origin_f,  origin, size, "hello", 1, 1);
	test_func(handmade_f, handmade, size, "hello", 1, 0);
	printf("\n");
	
	test_func(origin_f,  origin, size, "hello", 0, 1);
	test_func(handmade_f, handmade, size, "hello", 0, 0);
	printf("\n");
	
	//test_func(origin_f,  origin, size, "hello", -10, 1);
	//test_func(handmade_f, handmade, size, "hello", -10, 0);
	//printf("\n");

	test_func(origin_f,  origin, size, "hello", 20, 1);
	test_func(handmade_f, handmade, size, "hello", 20, 0);
	printf("\n");

	test_func(origin_f,  origin, size, "hello", 15, 1);
	test_func(handmade_f, handmade, size, "hello", 15, 0);
	printf("\n");
	return (0);
}
