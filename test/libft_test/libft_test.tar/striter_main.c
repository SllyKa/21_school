/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_template.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 16:38:04 by gbrandon          #+#    #+#             */
/*   Updated: 2018/12/03 13:24:37 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libc.h>
#include <stdlib.h>
#include "libft.h"
#include "libextra.h"
#include <errno.h>
#include <ctype.h>
#include <limits.h>

# define TEST_NAME "striter_res"

void	test_func_for_striter(char *a)
{
	*a = *a + 2;
}

void	errno_ch_and_pr(void)
{
	printf("%-15s%s: %i\n", "errno_res:", strerror(errno), errno);
	errno = 0;
}

void	s_print(char *str, size_t s)
{
	size_t i;

	i = 0;
	while (i < s)
	{
			printf("%c ", *str);
			i++;
			str++;
	}	
	printf("\n");
}

void    *mem_al(size_t n)
{
   void *a = malloc(n);
   return a;
}

void    mem_free(void *ptr)
{
	    free(ptr);
}

int     test_func(void (*f)(char *str, void (*)(char*)), void (*test_func)(char*), char *str, size_t str_size,
		char *txt1, int f_type)
{
	strcpy(str, txt1);
	//strcpy(str2, txt2);

	f(str, test_func);

	if (f_type)
		printf("%-15s", "origin_res:");
	else
		printf("%-15s", "handmade_res:");
	printf("%-15s%s\n",TEST_NAME, str);
	s_print(str, str_size);
	//bits(ptr_size, ptr);

	return (0);
}

int		main(void)
{
	extern int errno;
	size_t s = 50;
	//size_t s2 = 20;

	//void	(*origin_f)(char *str) = &tolower;
	void	(*handmade)(char *str, void (*)(char*)) = &ft_striter;
	void	(*ftest)(char *) = &test_func_for_striter;

	char *origin = (char*)mem_al(s);
	//void *origin2 = mem_al(s2);
	
	printf("\v\v\v\v\v");
	printf("%30c%s#\n\n",'#', TEST_NAME); 

	test_func(handmade, ftest, origin, s, "", 0);
	test_func(handmade, ftest, origin, s, "\0\0", 0);
	test_func(handmade, ftest, origin, s, "hello!hello!hello!hello!hello!hello!", 0);
	test_func(handmade, ftest, origin, s, "hello!", 0);
	test_func(handmade, ftest, origin, s, "abcdefghijkl!@#$%^&*()", 0);
	test_func(handmade, ftest, origin, s, "\37\37\37\37", 0);
	test_func(handmade, NULL, origin, s, "hallo!", 0);

	return (0);
}
