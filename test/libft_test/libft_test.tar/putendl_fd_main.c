/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_template.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 16:38:04 by gbrandon          #+#    #+#             */
/*   Updated: 2018/12/03 12:56:57 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libc.h>
#include <stdlib.h>
#include "libft.h"
#include "libextra.h"
#include <errno.h>
#include <ctype.h>
#include <limits.h>

# define TEST_NAME "putendl_fd_res"

void	s_print(char *ptr, size_t s)
{
	size_t i;

	i = 0;
	while (i < s)
	{
			printf("%c ", *ptr);
			i++;
			ptr++;
	}	
	printf("\n");
}

void    *mem_al(size_t n)
{
   void *a = malloc(n);
   return a;
}

void    mem_free(void *ptr)
{
	    free(ptr);
}

int		test_func(void (*f)(const char*, int d),char *str, size_t str_size, char *str1, int fd)
{
	//int cmp_res = 0;
	strcpy(str, str1);
	//strcpy((char*)ptr2, str2);
	str_size = 1;
	f(str, fd);

	//s_print(str, str_size);
	//printf("%-15s|%s|\n",TEST_NAME, temp_res);
	//printf("%-15s%i\n", "cmp_result:", cmp_res);
	//bits(ptr_size, ptr);
	//printf("\n");

	return (0);
}

int		main(void)
{
	size_t s = 35;
	//size_t s2 = 20;

	//size_t		(*origin_f)(const char *str) = &strlen;
	void		(*handmade)(const char *str, int fd) = &ft_putendl_fd;

	char *origin = (char*)mem_al(s);
	//char *origin2 = (char*)mem_al(s2);

	test_func(handmade, origin, s, "privet_chelover", 1);
	printf("\n");

	test_func(handmade, origin, s, "", 1);
	printf("\n");

	test_func(handmade, origin, s, "h", 2);
	printf("\n");

	test_func(handmade, origin, s, "**()%^$\0%^#%^&", 2);
	printf("\n");

	test_func(handmade, origin, s, "\0\0\0\0\0\0", 1);
	printf("\n");

	test_func(handmade, origin, s, "opa\377papa", 1);
	printf("\n");

	test_func(handmade, origin, s, "opa\377papa", 2);
	printf("\n");

	test_func(handmade, origin, s, "opa\377papa", 0);
	printf("\n");

	test_func(handmade, origin, s, "opa\344papa", 10);
	printf("\n");

	test_func(handmade, origin, s, "opa\344papa", 10204930);
	printf("\n");

	test_func(handmade, origin, s, "opa\344papa", -5);
	printf("\n");

	return (0);
}
