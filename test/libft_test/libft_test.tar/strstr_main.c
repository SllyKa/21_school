/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_template.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 16:38:04 by gbrandon          #+#    #+#             */
/*   Updated: 2018/11/24 20:40:22 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libc.h>
#include <stdlib.h>
#include "libft.h"
#include "libextra.h"

void	s_print(char *str, size_t s)
{
	size_t i;

	i = 0;
	while (i < s)
	{
			printf("%c ", *str);
			i++;
			str++;
	}	
	printf("\n");
}

void    *mem_al(size_t n)
{
   void *a = malloc(n);
   return a;
}

void    mem_free(void *ptr)
{
	    free(ptr);
}

int     test_func(char *(*f)(const char*, const char *), char *str1, size_t str_size,
		          char *str2, char *txt1, char *txt2, int f_type)
{
	char	*new_str;
	strcpy(str1, txt1);
	strcpy(str2, txt2);

	new_str = f(str1, str2);
	printf("%-15s%s\n","strchr_res:", new_str);

	if (f_type)
		printf("%-15s", "origin_res:");
	else
		printf("%-15s", "handmade_res:");
	s_print(str1, str_size);
	//bits(ptr_size, ptr);

	return (0);
}

int		main(void)
{
	size_t s = 50;
	size_t s2 = 20;

	char	*(*origin_f)(const char *dst, const char *s2) = &strstr;
	char	*(*handmade)(const char *dst, const char *s2) = &ft_strstr;

	void *origin = mem_al(s);
	void *origin2 = mem_al(s2);

	test_func(origin_f, origin, s, origin2, "privetk_chelokver", "k", 1);
	test_func(handmade, origin, s, origin2, "privetk_chelokver", "k", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "privet_chenlovern", "nlo", 1);
	test_func(handmade, origin, s, origin2, "privet_chenlovern", "nlo", 0);
	printf("\n");
	
	test_func(origin_f, origin, s, origin2, "privetn_chelonver", "onver", 1);
	test_func(handmade, origin, s, origin2, "privetn_chelonver", "onver", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "privet_nchenlover", "privet", 1);
	test_func(handmade, origin, s, origin2, "privet_nchenlover", "privet", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "\0", "\0", 1);
	test_func(handmade, origin, s, origin2, "\0", "\0", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "men\0_opa", "\0_op", 1);
	test_func(handmade, origin, s, origin2, "men\0_opa", "\0_op", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "topazzz", "topazzz", 1);
	test_func(handmade, origin, s, origin2, "topazzz", "topazzz", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "topazzz", "topazzzz", 1);
	test_func(handmade, origin, s, origin2, "topazzz", "topazzzz", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "topattoptoptop", "t", 1);
	test_func(handmade, origin, s, origin2, "topattoptoptop", "t", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "privet_nnnchennnnlover", "nn", 1);
	test_func(handmade, origin, s, origin2, "privet_nnnchennnnlover", "nn", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "mmmmmmmnmnmnmnnn", "mmmmmmmm", 1);
	test_func(handmade, origin, s, origin2, "mmmmmmmnmnmnmnnn", "mmmmmmmm", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "strststrsstrstr", "strstr", 1);
	test_func(handmade, origin, s, origin2, "strststrsstrstr", "strstr", 0);
	printf("\n");

	//test_func(origin_f, NULL, s, origin2, 0, "privet_chelover", "poka_men");
	//test_func(handmade, NULL, s, origin2, 0, "privet_chelover", "poka_men");
	//printf("\n");

	test_func(origin_f, origin, s, origin2, "prizvet_cheloverz", "z", 1);
	test_func(handmade, origin, s, origin2, "prizvet_cheloverz", "z", 0);
	printf("\n");

	//test_func(origin_f, origin, s, origin2, -10, "privet_chelover", "poka_men");
	//test_func(handmade, origin, s, origin2, -10, "privet_chelover", "poka_men");
	//printf("\n");
	
	test_func(origin_f, origin, s, origin2, "ststrstrststrsstrsstrrtstrstrstr", "strstrstr", 1);
	test_func(handmade, origin, s, origin2, "ststrstrststrsstrsstrrtstrstrstr", "strstrstr", 0);
	printf("\n");
	
	test_func(origin_f, origin, s, origin2, "privet_chelover", "prov", 1);
	test_func(handmade, origin, s, origin2, "privet_chelover", "prov", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "pr=ivet===_chelover", " pr=", 1);
	test_func(handmade, origin, s, origin2, "pr=ivet===_chelover", " pr=", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "*prpr*prpri*pr", "pri", 1);
	test_func(handmade, origin, s, origin2, "*prpr*prpri*pr", "pri", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "*privet_chelover*", "\52", 1);
	test_func(handmade, origin, s, origin2, "*privet_chelover*", "\52", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "privet\377_che254lover", "255", 1);
	test_func(handmade, origin, s, origin2, "privet\377_che254lover", "255", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "privet\377_chelover\254", "\377_chelover", 1);
	test_func(handmade, origin, s, origin2, "privet\377_chelover\254", "\377_chelover", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "pr\177i\177vet\377_chelover\254", "\177i\177", 1);
	test_func(handmade, origin, s, origin2, "pr\177i\177vet\377_chelover\254", "\177i\177", 0);
	printf("\n");
	return (0);
}
