/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_template.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 16:38:04 by gbrandon          #+#    #+#             */
/*   Updated: 2018/12/03 15:01:00 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libc.h>
#include <stdlib.h>
#include "libft.h"
#include "libextra.h"

void	s_print(void *ptr, size_t s)
{
	size_t i;

	i = 0;
	while (i < s)
	{
			printf("%c ", *((char*)ptr));
			i++;
			ptr++;
	}	
	printf("\n");
}

void    *mem_al(size_t n)
{
   void *a = malloc(n);
   return a;
}

void    mem_free(void *ptr)
{
	    free(ptr);
}

int		test_func(void	*(*f)(void*, const void*, size_t n), void *ptr, size_t ptr_size, void *ptr2,
		size_t number_of_bytes, char *str1, char* str2)
{
	strcpy((char*)ptr, str1);
	strcpy((char*)ptr2, str2);

	ptr = f(ptr, ptr2, number_of_bytes);

	s_print(ptr, ptr_size);
	bits(ptr_size, ptr);
	printf("\n");

	return (0);
}

int		main(void)
{
	size_t s = 15;
	size_t s2 = 20;

	void	*(*origin_f)(void *dst, const void *src, size_t n) = &memmove;
	void	*(*handmade)(void *dst, const void *src, size_t n) = &ft_memmove;

	void *origin = mem_al(s);
	void *origin2 = mem_al(s2);

	test_func(origin_f, origin, s, origin2, 10, "privet_chelover", "poka_men");
	test_func(handmade, origin, s, origin2, 10, "privet_chelover", "poka_men");
	printf("\n");

	test_func(origin_f, origin, s, origin2, 0, "privet_chelover", "poka_men");
	test_func(handmade, origin, s, origin2, 0, "privet_chelover", "poka_men");
	printf("\n");

	test_func(origin_f, origin, s, origin2, 5, "privet_chelover", "poka_men");
	test_func(handmade, origin, s, origin2, 5, "privet_chelover", "poka_men");
	printf("\n");

	test_func(origin_f, origin, s, origin2, 8, "privet_chelover", "poka_men");
	test_func(handmade, origin, s, origin2, 8, "privet_chelover", "poka_men");
	printf("\n");
	
	//test_func(origin_f, NULL, s, origin2, 0, "privet_chelover", "poka_men");
	//test_func(handmade, NULL, s, origin2, 0, "privet_chelover", "poka_men");
	//printf("\n");

	test_func(origin_f, origin, s, origin2, 200000, "privet_chelover", "poka_men");
	test_func(handmade, origin, s, origin2, 200000, "privet_chelover", "poka_men");
	printf("\n");

	//test_func(origin_f, origin, s, origin2, -10, "privet_chelover", "poka_men");
	//test_func(handmade, origin, s, origin2, -10, "privet_chelover", "poka_men");
	//printf("\n");
	
	test_func(origin_f, origin + 10, s, origin, 14, "privet_chelover", "privet_chelover");
	test_func(handmade, origin + 10, s, origin, 14, "privet_chelover", "privet_chelover");
	printf("\n");
	
	test_func(origin_f, origin, s, origin + 3, 14, "privet_chelover", "vet_chelover");
	test_func(handmade, origin, s, origin + 3, 14, "privet_chelover", "vet_chelover");
	printf("\n");

	test_func(origin_f, origin, s, origin + 3, 14, "privet_che\376lover", "vet_che\376lover");
	test_func(handmade, origin, s, origin + 3, 14, "privet_che\376lover", "vet_che\376lover");
	printf("\n");

	test_func(origin_f, origin, s, origin + 3, 14, "privet_che\254Flover", "vet_che\254lover");
	test_func(handmade, origin, s, origin + 3, 14, "privet_che\254Flover", "vet_che\254lover");
	printf("\n");

	test_func(origin_f, origin, s, origin, 14, "privet_che\254Flover", "vet_che\254lover");
	test_func(handmade, origin, s, origin, 14, "privet_che\254Flover", "vet_che\254lover");
	printf("\n");

	test_func(origin_f, origin + 5, s, origin, 14, "privet_che\254Flover", "vet_che\254lover");
	test_func(handmade, origin + 5, s, origin, 14, "privet_che\254Flover", "vet_che\254lover");
	printf("\n");

	test_func(origin_f, origin + 1, s, origin, 14, "privet_che\254Flover", "vet_che\254lover");
	test_func(handmade, origin + 1, s, origin, 14, "privet_che\254Flover", "vet_che\254lover");
	printf("\n");

	printf("pointer: %p\n", origin_f(NULL, NULL, 10));
	printf("pointer: %p\n", handmade(NULL, NULL, 10));
	return (0);
}
