/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_template.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 16:38:04 by gbrandon          #+#    #+#             */
/*   Updated: 2018/12/06 10:54:52 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libc.h>
#include <stdlib.h>
#include "libft.h"
#include "libextra.h"
#include <errno.h>
#include <ctype.h>
#include <limits.h>

# define TEST_NAME "strnequ_res"

void	s_print(char *str, size_t s)
{
	size_t i;

	i = 0;
	while (i < s)
	{
			printf("%c ", *str);
			i++;
			str++;
	}	
	printf("\n");
}

void    *mem_al(size_t n)
{
   void *a = malloc(n);
   return a;
}

void    mem_free(void *ptr)
{
	    free(ptr);
}

int     test_func(int (*f)(const char*, const char *, size_t n), char *str1, size_t str_size,
		          char *str2, char *txt1, char *txt2, size_t len, int f_type)
{
	int	cmp_res;
	strcpy(str1, txt1);
	strcpy(str2, txt2);

	cmp_res = f(str1, str2, len);
	printf("%-15s%d\n",TEST_NAME, cmp_res);
	if (f_type)
		printf("%-15s", "origin_res:");
	else
		printf("%-15s", "handmade_res:");
	s_print(str1, str_size);
	//bits(ptr_size, ptr);

	return (0);
}

int		main(void)
{
	size_t s = 50;
	size_t s2 = 20;

	int		(*origin_f)(const char *dst, const char *s2, size_t n) = &strncmp;
	int		(*handmade)(const char *dst, const char *s2, size_t n) = &ft_strnequ;

	void *origin = mem_al(s);
	void *origin2 = mem_al(s2);

	printf("\v\v\v\v\v");
	printf("%30c%s#\n\n",'#', TEST_NAME); 

	test_func(origin_f, origin, s, origin2, "privet_chelokver", "privet_chelokver", 16, 1);
	test_func(handmade, origin, s, origin2, "privet_chelokver", "privet_chelokver", 16, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "privet_chenlovern", "privet_chenlovere", 15, 1);
	test_func(handmade, origin, s, origin2, "privet_chenlovern", "privet_chenlovere", 15, 0);
	printf("\n");
	
	test_func(origin_f, origin, s, origin2, "privetn_chelonver", "onver", 1, 1);
	test_func(handmade, origin, s, origin2, "privetn_chelonver", "onver", 1, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "privet_nchenlover", "privet", 6, 1);
	test_func(handmade, origin, s, origin2, "privet_nchenlover", "privet", 6, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "privet_nchenlover", "privet", 5, 1);
	test_func(handmade, origin, s, origin2, "privet_nchenlover", "privet", 5, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "privet_nchenlover", "privet", 4, 1);
	test_func(handmade, origin, s, origin2, "privet_nchenlover", "privet", 4, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "\0", "\0", 10, 1);
	test_func(handmade, origin, s, origin2, "\0", "\0", 10, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "", "", 1, 1);
	test_func(handmade, origin, s, origin2, "", "", 1, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "men\0_opa", "\0_op", 3, 1);
	test_func(handmade, origin, s, origin2, "men\0_opa", "\0_op", 3, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "topazzz", "aopazzz", 0, 1);
	test_func(handmade, origin, s, origin2, "topazzz", "aopazzz", 0, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "topazzz", "topazzzz", 7, 1);
	test_func(handmade, origin, s, origin2, "topazzz", "topazzzz", 7, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "topattoptoptop", "topatt!optoptop", 7, 1);
	test_func(handmade, origin, s, origin2, "topattoptoptop", "topatt!optoptop", 7, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "privet_nnnchennnnlover", " privet_nnnchennnnlover", 100, 1);
	test_func(handmade, origin, s, origin2, "privet_nnnchennnnlover", " privet_nnnchennnnlover", 100, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "mmmmmmmnmnmnmnnn", "mmmmmmmm", 2, 1);
	test_func(handmade, origin, s, origin2, "mmmmmmmnmnmnmnnn", "mmmmmmmm", 2, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "strststrstrstrstr", "strstr", 11, 1);
	test_func(handmade, origin, s, origin2, "strststrsstrstr", "strstr", 11, 0);
	printf("\n");

	//test_func(origin_f, NULL, s, origin2, 0, "privet_chelover", "poka_men");
	//test_func(handmade, NULL, s, origin2, 0, "privet_chelover", "poka_men");
	//printf("\n");

	test_func(origin_f, origin, s, origin2, "prizvet_cheloverz", "p", 1, 1);
	test_func(handmade, origin, s, origin2, "prizvet_cheloverz", "p", 1, 0);
	printf("\n");

	//test_func(origin_f, origin, s, origin2, -10, "privet_chelover", "poka_men");
	//test_func(handmade, origin, s, origin2, -10, "privet_chelover", "poka_men");
	//printf("\n");
	
	test_func(origin_f, origin, s, origin2, "ststrstrststrsstrsstrrtstrstrstr", "strstrstr", 24, 1);
	test_func(handmade, origin, s, origin2, "ststrstrststrsstrsstrrtstrstrstr", "strstrstr", 24, 0);
	printf("\n");
	
	test_func(origin_f, origin, s, origin2, "privet_chelover", "privet chelover", 8, 1);
	test_func(handmade, origin, s, origin2, "privet_chelover", "privet chelover", 8, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "pr=ivet===_chelover", " pr=", 3, 1);
	test_func(handmade, origin, s, origin2, "pr=ivet===_chelover", " pr=", 3, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "*prpr*prpri*pr", "pri", 11, 1);
	test_func(handmade, origin, s, origin2, "*prpr*prpri*pr", "pri", 11, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "*privet_chelover*", "\52privet_chelover\52", 10, 1);
	test_func(handmade, origin, s, origin2, "*privet_chelover*", "\52privet_chelover\52", 10, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "privet\377_che254lover", "privet\377_che254lover", 99, 1);
	test_func(handmade, origin, s, origin2, "privet\377_che254lover", "privet\377_che254lover", 99, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "privet\377_chelover\254", "\377_chelover", 1, 1);
	test_func(handmade, origin, s, origin2, "privet\377_chelover\254", "\377_chelover", 1, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "pr\177i\177vet\377_chelover\254", "\177i\177", 9, 1);
	test_func(handmade, origin, s, origin2, "pr\177i\177vet\377_chelover\254", "\177i\177", 9, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "kotya", "kotya_koshka", 6, 1);
	test_func(handmade, origin, s, origin2, "kotya", "kotya_koshka", 6, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "kotya", "", 6, 1);
	test_func(handmade, origin, s, origin2, "kotya", "", 6, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "kotya", "", 0, 1);
	test_func(handmade, origin, s, origin2, "kotya", "", 0, 0);
	printf("\n");
	
	test_func(origin_f, origin, s, origin2, "", "kotya_koshka", 6, 1);
	test_func(handmade, origin, s, origin2, "", "kotya_koshka", 6, 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "", "kotya_koshka", 0, 1);
	test_func(handmade, origin, s, origin2, "", "kotya_koshka", 0, 0);
	printf("\n");

	return (0);
}
