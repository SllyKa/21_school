/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_template.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 16:38:04 by gbrandon          #+#    #+#             */
/*   Updated: 2018/12/03 13:09:12 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libc.h>
#include <stdlib.h>
#include "libft.h"
#include "libextra.h"
#include <errno.h>
#include <ctype.h>
#include <limits.h>

# define TEST_NAME "putnbr_fd_res"

void	s_print(char *ptr, size_t s)
{
	size_t i;

	i = 0;
	while (i < s)
	{
			printf("%c ", *ptr);
			i++;
			ptr++;
	}	
	printf("\n");
}

void    *mem_al(size_t n)
{
   void *a = malloc(n);
   return a;
}

void    mem_free(void *ptr)
{
	    free(ptr);
}

int		test_func(void (*f)(int, int),int num, int fd)
{
	//int cmp_res = 0;
	//strcpy(str, str1);
	//strcpy((char*)ptr2, str2);
	f(num, fd);

	//s_print(str, str_size);
	//printf("%-15s|%s|\n",TEST_NAME, temp_res);
	//printf("%-15s%i\n", "cmp_result:", cmp_res);
	//bits(ptr_size, ptr);
	//printf("\n");

	return (0);
}

int		main(void)
{
	//size_t s = 35;
	//size_t s2 = 20;

	//size_t		(*origin_f)(const char *str) = &strlen;
	void		(*handmade)(int a, int fd) = &ft_putnbr_fd;

	//char *origin = (char*)mem_al(s);
	//char *origin2 = (char*)mem_al(s2);

	test_func(handmade, 1, 1);
	printf("\n");
	
	test_func(handmade, -5, 1);
	printf("\n");
	
	test_func(handmade, -0, 1);
	printf("\n");
	
	test_func(handmade, -199, 1);
	printf("\n");
	
	test_func(handmade, 194, 1);
	printf("\n");

	test_func(handmade, 0, 1);
	printf("\n");
	
	test_func(handmade, -129567, 1);
	printf("\n");
	
	test_func(handmade, 2147483647, 1);
	printf("\n");
	
	test_func(handmade, -2147483648, 1);
	printf("\n");
	
	test_func(handmade, -129567, 2);
	printf("\n");
	
	test_func(handmade, -2147483648, 2);
	printf("\n");
	
	test_func(handmade, -129567, 10);
	printf("\n");
	
	test_func(handmade, -129567, -100);
	printf("\n");
	
	return (0);
}
