/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_template.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 16:38:04 by gbrandon          #+#    #+#             */
/*   Updated: 2018/11/23 16:51:13 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libc.h>
#include <stdlib.h>
#include "libft.h"
#include "libextra.h"

void	s_print(void *ptr, size_t s)
{
	size_t i;

	i = 0;
	while (i < s)
	{
			printf("%c ", *((char*)ptr));
			i++;
			ptr++;
	}	
	printf("\n");
}

void    *mem_al(size_t n)
{
   void *a = malloc(n);
   return a;
}

void    mem_free(void *ptr)
{
	    free(ptr);
}

int		test_func(int (*f)(const void*, const void*, size_t n), void *ptr, size_t ptr_size, void *ptr2,
		size_t number_of_bytes, char *str1, char* str2)
{
	int cmp_res = 0;
	strcpy((char*)ptr, str1);
	strcpy((char*)ptr2, str2);

	cmp_res = f(ptr, ptr2, number_of_bytes);

	s_print(ptr, ptr_size);
	printf("%-15s%i","cmp_res:", cmp_res);
	//bits(ptr_size, ptr);
	printf("\n");

	return (0);
}

int		main(void)
{
	size_t s = 15;
	size_t s2 = 20;

	int		(*origin_f)(const void *dst, const void *src, size_t n) = &memcmp;
	int		(*handmade)(const void *dst, const void *src, size_t n) = &ft_memcmp;

	void *origin = mem_al(s);
	void *origin2 = mem_al(s2);

	test_func(origin_f, origin, s, origin2, 10, "privet_chelover", "poka_men");
	test_func(handmade, origin, s, origin2, 10, "privet_chelover", "poka_men");
	printf("\n");

	test_func(origin_f, origin, s, origin2, 0, "privet_chelover", "poka_men");
	test_func(handmade, origin, s, origin2, 0, "privet_chelover", "poka_men");
	printf("\n");

	test_func(origin_f, origin, s, origin2, 5, "privet_chelover", "privet_men");
	test_func(handmade, origin, s, origin2, 5, "privet_chelover", "privet_men");
	printf("\n");

	test_func(origin_f, origin, s, origin2, 7, "privet_chelover", "privet_men");
	test_func(handmade, origin, s, origin2, 7, "privet_chelover", "privet_men");
	printf("\n");
	
	test_func(origin_f, origin, s, origin2, 8, "privet_chelover", "privet_cmen");
	test_func(handmade, origin, s, origin2, 8, "privet_chelover", "privet_cmen");
	printf("\n");

	test_func(origin_f, origin, s, origin2, 9, "privet_chelover", "privet_cmen");
	test_func(handmade, origin, s, origin2, 9, "privet_chelover", "privet_cmen");
	printf("\n");

	//test_func(origin_f, NULL, s, origin2, 0, "privet_chelover", "poka_men");
	//test_func(handmade, NULL, s, origin2, 0, "privet_chelover", "poka_men");
	//printf("\n");

	test_func(origin_f, origin, s, origin2, 200000, "privet_chelover", "privet_chelover");
	test_func(handmade, origin, s, origin2, 200000, "privet_chelover", "privet_chelover");
	printf("\n");

	test_func(origin_f, origin, s, origin2, 200000, "privet_chelover", "privet_chelover_opa");
	test_func(handmade, origin, s, origin2, 200000, "privet_chelover", "privet_chelover_opa");
	printf("\n");
	//test_func(origin_f, origin, s, origin2, -10, "privet_chelover", "poka_men");
	//test_func(handmade, origin, s, origin2, -10, "privet_chelover", "poka_men");
	//printf("\n");
	
	test_func(origin_f, origin, s, origin2, 14, "privet_chelover", "privet_chelovek");
	test_func(handmade, origin, s, origin2, 14, "privet_chelover", "privet_chelovek");
	printf("\n");
	
	test_func(origin_f, origin, s, origin2, 14, "privet_chelover", "privet_chelover");
	test_func(handmade, origin, s, origin2, 14, "privet_chelover", "privet_chelover");
	printf("\n");

	test_func(origin_f, origin, s, origin2, 14, "", "");
	test_func(handmade, origin, s, origin2, 14, "", "");
	printf("\n");

	test_func(origin_f, origin, s, origin2, 14, "privet", "");
	test_func(handmade, origin, s, origin2, 14, "privet", "");
	printf("\n");

	test_func(origin_f, origin, s, origin2, 14, "", "privet");
	test_func(handmade, origin, s, origin2, 14, "", "privet");
	printf("\n");
	
	test_func(origin_f, origin, s, origin2, 14, "\200", "\200");
	test_func(handmade, origin, s, origin2, 14, "\200", "\200");
	printf("\n");

	test_func(origin_f, origin, s, origin2, 14, "\123", "\377");
	test_func(handmade, origin, s, origin2, 14, "\123", "\377");
	printf("\n");

	test_func(origin_f, origin, s, origin2, 14, "privet\67", "privet\255");
	test_func(handmade, origin, s, origin2, 14, "privet\67", "privet\255");
	printf("\n");
	return (0);
}
