/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_template.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 16:38:04 by gbrandon          #+#    #+#             */
/*   Updated: 2018/11/29 13:07:52 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libc.h>
#include <stdlib.h>
#include "libft.h"
#include "libextra.h"
#include <errno.h>
#include <ctype.h>
#include <limits.h>

# define TEST_NAME "strjoin_res"

void	s_print(char *ptr, size_t s)
{
	size_t i;

	i = 0;
	while (i < s)
	{
			printf("%c ", *ptr);
			i++;
			ptr++;
	}	
	printf("\n");
}

void    *mem_al(size_t n)
{
   void *a = malloc(n);
   return a;
}

void    mem_free(void *ptr)
{
	    free(ptr);
}

int		test_func_o(char *(*f)(char*, const char*),char *str1, size_t str_size, 
		char *str2, char *txt1, char *txt2, int f_type)
{
	char *temp_res;
	strcpy(str1, txt1);
	strcpy(str2, txt2);

	temp_res = f(str1, str2);
	printf("%-15s%s\n",TEST_NAME, temp_res);
	if (f_type)
		printf("%-15s", "origin_res:");
	else
		printf("%-15s", "handmade_res:");

	s_print(str1, str_size);
	//bits(ptr_size, ptr);

	return (0);
}

int		test_func(char *(*f)(const char*, const char*),char *str1, size_t str_size, 
		char *str2, char *txt1, char *txt2, int f_type)
{
	char *temp_res;
	strcpy(str1, txt1);
	strcpy(str2, txt2);

	temp_res = f(str1, str2);
	printf("%-15s%s\n",TEST_NAME, temp_res);
	if (f_type)
		printf("%-15s", "origin_res:");
	else
		printf("%-15s", "handmade_res:");

	s_print(str1, str_size);
	//bits(ptr_size, ptr);

	return (0);
}

int		main(void)
{
	size_t s = 15;
	size_t s2 = 20;

	char		*(*origin_f)(char *dest, const char *str) = &strcat;
	char		*(*handmade)(const char *dest, const char *str) = &ft_strjoin;

	char *origin = (char*)mem_al(s);
	char *origin2 = (char*)mem_al(s2);

	printf("\v\v\v\v\v");
	printf("%30c%s#\n\n",'#', TEST_NAME); 

	test_func_o(origin_f, origin, s, origin2, "privet_chelover", "poka_men", 1);
	test_func(handmade, origin, s, origin2, "privet_chelover", "poka_men", 0);
	printf("\n");

	test_func_o(origin_f, origin, s, origin2, "", "poka_men", 1);
	test_func(handmade, origin, s, origin2, "", "poka_men", 0);
	printf("\n");

	test_func_o(origin_f, origin, s, origin2, "privet chelover", "", 1);
	test_func(handmade, origin, s, origin2, "privet chelover", "", 0);
	printf("\n");

	test_func_o(origin_f, origin, s, origin2, "h", "poka men", 1);
	test_func(handmade, origin, s, origin2, "h", "poka men", 0);
	printf("\n");

	test_func_o(origin_f, origin, s, origin2, "**()%^$\0%^#%^&", "ha", 1);
	test_func(handmade, origin, s, origin2, "**()%^$\0%^#%^&", "ha", 0);
	printf("\n");

	test_func_o(origin_f, origin, s, origin2, "\0\0\0\0\0\0", "poka humans", 1);
	test_func(handmade, origin, s, origin2, "\0\0\0\0\0\0", "poka humans", 0);
	printf("\n");

	test_func_o(origin_f, origin, s, origin2, "\0", "poka humans", 1);
	test_func(handmade, origin, s, origin2, "\0", "poka humans", 0);
	printf("\n");

	test_func_o(origin_f, origin, s, origin2, "privet chelover", "\0\0", 1);
	test_func(handmade, origin, s, origin2, "privet chelover", "\0\0", 0);
	printf("\n");
	return (0);
}
