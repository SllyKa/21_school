/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_template.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 16:38:04 by gbrandon          #+#    #+#             */
/*   Updated: 2018/11/28 13:22:40 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libc.h>
#include <stdlib.h>
#include "libft.h"
#include "libextra.h"
#include <errno.h>
#include <ctype.h>
#include <limits.h>

# define TEST_NAME "memdel_res"

void	errno_ch_and_pr(void)
{
	printf("%-15s%s: %i\n", "errno_res:", strerror(errno), errno);
	errno = 0;
}

void	s_print(void *ptr, size_t s)
{
	size_t i;

	i = 0;
	while (i < s)
	{
			printf("%c ", *((char*)ptr));
			i++;
			ptr++;
	}	
	printf("\n");
}

void    *mem_al(size_t n)
{
   void *a = malloc(n);
   return a;
}

void    mem_free(void *ptr)
{
	    free(ptr);
}

int     test_func(void (*f)(void **ap), void **ap, int f_type)
{
	f(ap);

	if (f_type)
		printf("%-15s", "origin_res:");
	else
		printf("%-15s", "handmade_res:");
	printf("%-15s%p\n",TEST_NAME, ap);
	printf("%-15s%p\n",TEST_NAME, *ap);

	return (0);
}

int		main(void)
{
	extern int errno;
	size_t s = 50;
	//size_t s2 = 20;

	//void	*(*origin_f)(size_t c) = &malloc;
	void	(*handmade)(void **ap) = &ft_memdel;

	void *origin = mem_al(s);
	void **or_a = malloc(sizeof(void*) * 2);
	*or_a = origin;
	//void *origin2 = mem_al(s2);

	printf("\v\v\v\v\v");
	printf("%30c%s#\n\n",'#', TEST_NAME); 

	test_func(handmade, or_a, 0);
	printf("\n");

	return (0);
}
