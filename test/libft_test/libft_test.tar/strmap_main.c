/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_template.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 16:38:04 by gbrandon          #+#    #+#             */
/*   Updated: 2018/12/03 13:21:10 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libc.h>
#include <stdlib.h>
#include "libft.h"
#include "libextra.h"
#include <errno.h>
#include <ctype.h>
#include <limits.h>

# define TEST_NAME "strmap_res"

#define FUNC_ARG char (*test_f)(char)

char	test_func_for_striteri(char a)
{
	if (a >= '\141' && a <= '\172')
		return (a - 32);
	return (a);	
}

void	errno_ch_and_pr(void)
{
	printf("%-15s%s: %i\n", "errno_res:", strerror(errno), errno);
	errno = 0;
}

void	s_print(char *str, size_t s)
{
	size_t i;

	i = 0;
	while (i < s)
	{
			printf("%c ", *str);
			i++;
			str++;
	}	
	printf("\n");
}

void    *mem_al(size_t n)
{
   void *a = malloc(n);
   return a;
}

void    mem_free(void *ptr)
{
	    free(ptr);
}

int     test_func(char *(*f)(const char *str, FUNC_ARG), 
		FUNC_ARG, char *str, size_t str_size,
		char *txt1, int f_type)
{
	char	*new_str;
	strcpy(str, txt1);
	//strcpy(str2, txt2);

	new_str = f(str, test_f);

	printf("%-15s%s\n",TEST_NAME, new_str);
	if (f_type)
		printf("%-15s", "origin_res:");
	else
		printf("%-15s", "handmade_res:");
	s_print(str, str_size);
	//bits(ptr_size, ptr);

	return (0);
}

int		main(void)
{
	extern int errno;
	size_t s = 50;
	//size_t s2 = 20;

	FUNC_ARG = &test_func_for_striteri;
	//void	(*origin_f)(char *str) = &tolower;
	char	*(*handmade)(const char *str, FUNC_ARG) = &ft_strmap;

	char *origin = (char*)mem_al(s);
	//void *origin2 = mem_al(s2);
	
	printf("\v\v\v\v\v");
	printf("%30c%s#\n\n",'#', TEST_NAME); 

	test_func(handmade, test_f, origin, s, "", 0);
	printf("\n");
	test_func(handmade, test_f, origin, s, "\0\0", 0);
	printf("\n");
	test_func(handmade, test_f, origin, s, "hello!hello!hello!hello!hello!hello!", 0);
	printf("\n");
	test_func(handmade, test_f, origin, s, "hello!", 0);
	printf("\n");
	test_func(handmade, test_f, origin, s, "abcdefghijkl!@#$%^&*()", 0);
	printf("\n");
	test_func(handmade, test_f, origin, s, "#$$AaBbZz", 0);
	printf("\n");
	test_func(handmade, NULL, origin, s, "#$$AaBbZz", 0);
	printf("\n");
	return (0);
}
