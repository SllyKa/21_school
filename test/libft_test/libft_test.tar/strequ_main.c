/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_template.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 16:38:04 by gbrandon          #+#    #+#             */
/*   Updated: 2018/11/29 11:27:21 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libc.h>
#include <stdlib.h>
#include "libft.h"
#include "libextra.h"
#include <errno.h>
#include <ctype.h>
#include <limits.h>

# define TEST_NAME "strequ_res"

void	s_print(char *str, size_t s)
{
	size_t i;

	i = 0;
	while (i < s)
	{
			printf("%c ", *str);
			i++;
			str++;
	}	
	printf("\n");
}

void    *mem_al(size_t n)
{
   void *a = malloc(n);
   return a;
}

void    mem_free(void *ptr)
{
	    free(ptr);
}

int     test_func(int (*f)(const char*, const char *), char *str1, size_t str_size,
		          char *str2, char *txt1, char *txt2, int f_type)
{
	int	cmp_res;
	strcpy(str1, txt1);
	strcpy(str2, txt2);

	cmp_res = f(str1, str2);
	printf("%-15s%d\n",TEST_NAME, cmp_res);
	if (f_type)
		printf("%-15s", "origin_res:");
	else
		printf("%-15s", "handmade_res:");
	s_print(str1, str_size);
	//bits(ptr_size, ptr);

	return (0);
}

int		main(void)
{
	size_t s = 50;
	size_t s2 = 20;

	int		(*origin_f)(const char *dst, const char *s2) = &strcmp;
	int		(*handmade)(const char *dst, const char *s2) = &ft_strequ;

	void *origin = mem_al(s);
	void *origin2 = mem_al(s2);

	printf("\v\v\v\v\v");
	printf("%30c%s#\n\n",'#', TEST_NAME); 

	test_func(origin_f, origin, s, origin2, "privet_chelokver", "privet_chelokver", 1);
	test_func(handmade, origin, s, origin2, "privet_chelokver", "privet_chelokver", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "privet_chenlovern", "privet_chenlovere", 1);
	test_func(handmade, origin, s, origin2, "privet_chenlovern", "privet_chenlovere", 0);
	printf("\n");
	
	test_func(origin_f, origin, s, origin2, "privetn_chelonver", "onver", 1);
	test_func(handmade, origin, s, origin2, "privetn_chelonver", "onver", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "privet_nchenlover", "privet", 1);
	test_func(handmade, origin, s, origin2, "privet_nchenlover", "privet", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "\0", "\0", 1);
	test_func(handmade, origin, s, origin2, "\0", "\0", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "", "", 1);
	test_func(handmade, origin, s, origin2, "", "", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "men\0_opa", "\0_op", 1);
	test_func(handmade, origin, s, origin2, "men\0_opa", "\0_op", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "topazzz", "aopazzz", 1);
	test_func(handmade, origin, s, origin2, "topazzz", "aopazzz", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "topazzz", "topazzzz", 1);
	test_func(handmade, origin, s, origin2, "topazzz", "topazzzz", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "topattoptoptop", "topatt!optoptop", 1);
	test_func(handmade, origin, s, origin2, "topattoptoptop", "topatt!optoptop", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "privet_nnnchennnnlover", " privet_nnnchennnnlover", 1);
	test_func(handmade, origin, s, origin2, "privet_nnnchennnnlover", " privet_nnnchennnnlover", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "mmmmmmmnmnmnmnnn", "mmmmmmmm", 1);
	test_func(handmade, origin, s, origin2, "mmmmmmmnmnmnmnnn", "mmmmmmmm", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "strststrsstrstr", "strstr", 1);
	test_func(handmade, origin, s, origin2, "strststrsstrstr", "strstr", 0);
	printf("\n");

	//test_func(origin_f, NULL, s, origin2, 0, "privet_chelover", "poka_men");
	//test_func(handmade, NULL, s, origin2, 0, "privet_chelover", "poka_men");
	//printf("\n");

	test_func(origin_f, origin, s, origin2, "prizvet_cheloverz", "p", 1);
	test_func(handmade, origin, s, origin2, "prizvet_cheloverz", "p", 0);
	printf("\n");

	//test_func(origin_f, origin, s, origin2, -10, "privet_chelover", "poka_men");
	//test_func(handmade, origin, s, origin2, -10, "privet_chelover", "poka_men");
	//printf("\n");
	
	test_func(origin_f, origin, s, origin2, "ststrstrststrsstrsstrrtstrstrstr", "strstrstr", 1);
	test_func(handmade, origin, s, origin2, "ststrstrststrsstrsstrrtstrstrstr", "strstrstr", 0);
	printf("\n");
	
	test_func(origin_f, origin, s, origin2, "privet_chelover", "privet chelover", 1);
	test_func(handmade, origin, s, origin2, "privet_chelover", "privet chelover", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "pr=ivet===_chelover", " pr=", 1);
	test_func(handmade, origin, s, origin2, "pr=ivet===_chelover", " pr=", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "*prpr*prpri*pr", "pri", 1);
	test_func(handmade, origin, s, origin2, "*prpr*prpri*pr", "pri", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "*privet_chelover*", "\52privet_chelover\52", 1);
	test_func(handmade, origin, s, origin2, "*privet_chelover*", "\52privet_chelover\52", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "privet\377_che254lover", "privet\377_che254lover", 1);
	test_func(handmade, origin, s, origin2, "privet\377_che254lover", "privet\377_che254lover", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "privet\377_chelover\254", "\377_chelover", 1);
	test_func(handmade, origin, s, origin2, "privet\377_chelover\254", "\377_chelover", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "pr\177i\177vet\377_chelover\254", "\177i\177", 1);
	test_func(handmade, origin, s, origin2, "pr\177i\177vet\377_chelover\254", "\177i\177", 0);
	printf("\n");

	test_func(origin_f, origin, s, origin2, "kotya", "kotya_koshka", 1);
	test_func(handmade, origin, s, origin2, "kotya", "kotya_koshka", 0);
	printf("\n");
	return (0);
}
