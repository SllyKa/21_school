/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   memset_main.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 13:13:51 by gbrandon          #+#    #+#             */
/*   Updated: 2018/11/27 17:54:21 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libc.h>
#include <stdlib.h>
#include "libft.h"
#include "libextra.h"

int		test_func(mem_size, c, len)
{
	//logger(argv);
	void *str = malloc(mem_size);
	void *str_my = malloc(mem_size);	
	//free
	str = memset(str, c, len);
	if (!str)
		return (1);
	str_my = ft_memset(str_my, c, len);
	if (!str_my)
		return (1);

	int i = 0;
	char *a = (char*)str;
	printf("%-17s", "origin_res:");
	while (i < 10)
	{
		printf("%c", *a);
		i++;
		a++;
	}
	printf("\n");

	i = 0;
	char *b = (char*)str_my;
	printf("%-17s", "handmade_res:");
	while (i < 10)
	{
		printf("%c", *b);
		i++;
		b++;
	}
	printf("\n");
	bits(sizeof(str), str);
	printf("\n");
	bits(sizeof(str_my), str_my);
	printf("\n");
	printf("\n");

	return (0);
}

int		main(void)
{
	test_func(9, '!', 10);
	test_func(0, 155, 10);
	test_func(9999, 1, 100000);
	test_func(99, 256, 10);
	test_func(99, 1000, 10);
	test_func(99, 48, 10);
	test_func(100, 49, 11);
	test_func(25, 99, 1);
	test_func(0,0,0);
	test_func(214, -1, 10);
	test_func(300, -110, 1248);
	test_func(300, 2896733, 1248);
	test_func(300, 2896840, 1248);
//	test_func(20, 50, 2147483646);

	return (0);
}
