/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_template.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 16:38:04 by gbrandon          #+#    #+#             */
/*   Updated: 2018/11/29 12:48:24 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libc.h>
#include <stdlib.h>
#include "libft.h"
#include "libextra.h"
#include <errno.h>
#include <ctype.h>
#include <limits.h>

# define TEST_NAME "strsub_res"

void	s_print(char *str, size_t s)
{
	size_t i;

	i = 0;
	while (i < s)
	{
			printf("%c ", *str);
			i++;
			str++;
	}	
	printf("\n");
}

void    *mem_al(size_t n)
{
   void *a = malloc(n);
   return a;
}

void    mem_free(void *ptr)
{
	    free(ptr);
}

int     test_func(char	*(*f)(const char*, unsigned int start, size_t n), char *str1, size_t str_size,
		          char *txt1,unsigned int start,  size_t len, int f_type)
{
	char	*temp_res;
	strcpy(str1, txt1);
	//strcpy(str2, txt2);

	temp_res = f(str1, start, len);
	printf("%-15s%s\n",TEST_NAME, temp_res);
	if (f_type)
		printf("%-15s", "origin_res:");
	else
		printf("%-15s", "handmade_res:");
	s_print(str1, str_size);
	//bits(ptr_size, ptr);

	return (0);
}

int		main(void)
{
	size_t s = 50;
	//size_t s2 = 20;

	//int		(*origin_f)(const char *dst, const char *s2, size_t n) = &strncmp;
	char		*(*handmade)(const char *dst, unsigned int ui, size_t n) = &ft_strsub;

	void *origin = mem_al(s);
	//void *origin2 = mem_al(s2);

	printf("\v\v\v\v\v");
	printf("%30c%s#\n\n",'#', TEST_NAME); 

	test_func(handmade, origin, s, "privet_chelokver", 5, 7, 0);
	printf("\n");

	test_func(handmade, origin, s, "privet_chelokver", 5, 11, 0);
	printf("\n");

	test_func(handmade, origin, s, "privet_chelokver", 5, 12, 0);
	printf("\n");

	test_func(handmade, origin, s, "privet_chelokver", 5, 10, 0);
	printf("\n");

	test_func(handmade, origin, s, "privet_chelokver", 0, 8, 0);
	printf("\n");

	test_func(handmade, origin, s, "privet_chelokver", 1, 8, 0);
	printf("\n");

	test_func(handmade, origin, s, "privet_chelokver", 0, 16, 0);
	printf("\n");

	test_func(handmade, origin, s, "privet_chelokver", 0, 17, 0);
	printf("\n");

	test_func(handmade, origin, s, "privet_chelokver", 7, 1, 0);
	printf("\n");

	test_func(handmade, origin, s, "privet_chelokver", 7, 0, 0);
	printf("\n");

	test_func(handmade, origin, s, "privet_chelokver", 0, 0, 0);
	printf("\n");

	test_func(handmade, origin, s, "privet_chelokver", 15, 0, 0);
	printf("\n");

	test_func(handmade, origin, s, "privet_chelokver", 0, 1, 0);
	printf("\n");

	test_func(handmade, origin, s, "privet_chelokver", 15, 1, 0);
	printf("\n");

	test_func(handmade, origin, s, "\0", 1, 1, 0);
	printf("\n");

	test_func(handmade, origin, s, "", 1, 1, 0);
	printf("\n");

	test_func(handmade, origin, s, "", 1, 0, 0);
	printf("\n");

	test_func(handmade, origin, s, "men\0_opa", 1, 3, 0);
	printf("\n");

	test_func(handmade, origin, s, "!@#$%^&*()n", 0, 10, 0);
	printf("\n");

	test_func(handmade, origin, s, "pr=ivet===_chelover", 3, 8, 0);
	printf("\n");

	test_func(handmade, origin, s, "\52privet_chelover\52", 0, 17, 0);
	printf("\n");

	test_func(handmade, origin, s, "privet\377_che254lover", 5, 15, 0);
	printf("\n");

	test_func(handmade, origin, s, "privet\377_chelover\254", 13, 5, 0);
	printf("\n");

	test_func(handmade, origin, s, "pr\177i\177vet\377_chelover\254", 1, 5, 0);
	printf("\n");

	test_func(handmade, origin, s, "privet_chelokver", 20, 10, 0);
	printf("\n");

	test_func(handmade, origin, s, "privet_chelokver", 5, 99, 0);
	printf("\n");

	return (0);
}
