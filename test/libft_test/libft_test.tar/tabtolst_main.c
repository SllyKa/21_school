/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_template.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 16:38:04 by gbrandon          #+#    #+#             */
/*   Updated: 2018/12/06 11:55:59 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libc.h>
#include <stdlib.h>
#include "libft.h"
#include "libextra.h"
#include <errno.h>
#include <ctype.h>
#include <limits.h>

# define TEST_NAME "strsplit_res"

void	list_print(t_list *list)
{
	while (list)
	{
		printf("%-20s%s%s\n", "content", " -> ", (char*)list->content);
		printf("%-20s%s%lu\n", "content_size:" , " -> ", list->content_size);
		printf("%-20s%s%p\n", "next", " -> ", list->next);
		list = list->next;
	}
}

void	print_tab(char **tab)
{
	while(*tab)
	{
		printf("|%s|\n", *tab);
		tab++;
	}
}

void	s_print(char *ptr, size_t s)
{
	size_t i;

	i = 0;
	while (i < s)
	{
			printf("%c ", *ptr);
			i++;
			ptr++;
	}	
	printf("\n");
}

void    *mem_al(size_t n)
{
   void *a = malloc(n);
   return a;
}

void    mem_free(void *ptr)
{
	    free(ptr);
}

int		test_func(char **(*f)(const char*, char c),char *str1, size_t str_size, 
		char *txt1, char c, int f_type)
{
	char **head_temp_res;
	char **temp_res;
	t_list	*head;

	str_size = 1;					/// !! str_size
	strcpy(str1, txt1);
	//strcpy(str2, txt2);

	temp_res = f(str1, c);
	head_temp_res = temp_res;
	printf("source_str: %s\n", str1);
	//printf("%-15s|%s|\n",TEST_NAME, temp_res);
	if (f_type)
		printf("%-15s\n", "origin_res:");
	else
		printf("%-15s\n", "handmade_res:");
	head = ft_tabtolst(temp_res);
	list_print(head);
	//print_tab(temp_res);
	//s_print(str1, str_size);
	//bits(ptr_size, ptr);
	while (*temp_res)
	{
		free(*temp_res);
		temp_res++;	
	}
	free(*temp_res);
	free(head_temp_res);
	return (0);
}

int		main(void)
{
	size_t s = 100;
	//size_t s2 = 20;

	//char		*(*origin_f)(char *dest, const char *str) = &strcat;
	char		**(*handmade)(const char *str, char c) = &ft_strsplit;

	char *origin = (char*)mem_al(s);
	//char *origin2 = (char*)mem_al(s2);

	printf("\v\v\v\v\v");
	printf("%30c%s#\n\n",'#', TEST_NAME); 

	test_func(handmade, origin, s,"privet_chel_over__", '_',  0);
	printf("\n");

	test_func(handmade, origin, s,"privet chel over ", '@',  0);
	printf("\n");

	test_func(handmade, origin, s,"privet@chel@over ", '@',  0);
	printf("\n");

	test_func(handmade, origin, s, "", '2', 0);
	printf("\n");

	/*
	test_func(handmade, origin, s, "     p r i v e t chelover", ' ', 0);
	printf("\n");

	test_func(handmade, origin, s, "privet chel o v er    ", 'p', 0);
	printf("\n");

	test_func(handmade, origin, s, "**()%    *   ^$\0%^#%^&", '*', 0);
	printf("\n");

	test_func(handmade, origin, s," \0 \0 \0 \0 \0 \0", '\0', 0);
	printf("\n");

	test_func(handmade, origin, s, "\0", 'h', 0);
	printf("\n");

	test_func(handmade, origin, s, "))p))))rivet)chel)ove)))r))", ')', 0);
	printf("\n");

	test_func(handmade, origin, s, "pr i v e t               c h e l o v e r                   !", '!', 0);
	printf("\n");

	test_func(handmade, origin, s, "\n\n\n\n\na\r\r\r\t\t\ta\n\n\t   \n \t        !", '\r', 0);
	printf("\n");

	test_func(handmade, origin, s, "\n\n\n\n\na\r\r\r\t\t\ta\n\n\t   \n \t        \0", '\n', 0);
	printf("\n");

	test_func(handmade, origin, s, "p          r\ti\tv\tet c\thel\no ver ", '\t', 0);
	printf("\n");

	test_func(handmade, origin, s, "                                      ", ' ', 0);
	printf("\n");
*/
	free(origin);
	return (0);
}
