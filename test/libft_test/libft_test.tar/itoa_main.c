/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_template.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 16:38:04 by gbrandon          #+#    #+#             */
/*   Updated: 2018/11/30 16:47:47 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libc.h>
#include <stdlib.h>
#include "libft.h"
#include "libextra.h"
#include <errno.h>
#include <ctype.h>
#include <limits.h>

# define TEST_NAME "itoa_res"

void	print_tab(char **tab)
{
	while(*tab)
	{
		printf("|%s|\n", *tab);
		tab++;
	}
}

void	s_print(char *ptr, size_t s)
{
	size_t i;

	i = 0;
	while (i < s)
	{
			printf("%c ", *ptr);
			i++;
			ptr++;
	}	
	printf("\n");
}

void    *mem_al(size_t n)
{
   void *a = malloc(n);
   return a;
}

void    mem_free(void *ptr)
{
	    free(ptr);
}

int		test_func(char *(*f)(int n),
		int num, int f_type)
{
	char *temp_res;

	//strcpy(str1, txt1);
	//strcpy(str2, txt2);

	temp_res = f(num);
	//printf("source_str: %s\n", str1);
	printf("%-15s|%s|\n",TEST_NAME, temp_res);
	if (f_type)
		printf("%-15s", "origin_res:");
	else
		printf("%-15s", "handmade_res:");
	//print_tab(temp_res);
	//s_print(str1, str_size);
	//bits(ptr_size, ptr);

	return (0);
}

int		main(void)
{
	//size_t s = 35;
	//size_t s2 = 20;

	//char		*(*origin_f)(char *dest, const char *str) = &strcat;
	char		*(*handmade)(int n) = &ft_itoa;

	//char *origin = (char*)mem_al(s);
	//char *origin2 = (char*)mem_al(s2);

	printf("\v\v\v\v\v");
	printf("%30c%s#\n\n",'#', TEST_NAME); 

	test_func(handmade, 1,  0);
	printf("\n");

	test_func(handmade, 193,  0);
	printf("\n");

	test_func(handmade, -200,  0);
	printf("\n");

	test_func(handmade, 0,  0);
	printf("\n");

	test_func(handmade, 20000567,  0);
	printf("\n");

	test_func(handmade, -20000567,  0);
	printf("\n");

	test_func(handmade, -2147483648,  0);
	printf("\n");

	test_func(handmade, 2147483647,  0);
	printf("\n");

	return (0);
}
