/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_template.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 16:38:04 by gbrandon          #+#    #+#             */
/*   Updated: 2018/11/23 20:12:27 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libc.h>
#include <stdlib.h>
#include "libft.h"
#include "libextra.h"

void	s_print(char *ptr, size_t s)
{
	size_t i;

	i = 0;
	while (i < s)
	{
			printf("%c ", *ptr);
			i++;
			ptr++;
	}	
	printf("\n");
}

void    *mem_al(size_t n)
{
   void *a = malloc(n);
   return a;
}

void    mem_free(void *ptr)
{
	    free(ptr);
}

int		test_func(char *(*f)(const char*),char *str, size_t str_size, char *str1)
{
	char *new_str;
	strcpy(str, str1);
	//strcpy((char*)ptr2, str2);

	new_str = f(str);
	if (!new_str)
	{
		printf("%-15s\n", "NULL appeaered!");
	}

	s_print(new_str, str_size);
	//bits(ptr_size, ptr);

	return (0);
}

int		main(void)
{
	size_t s = 15;
	//size_t s2 = 20;

	char		*(*origin_f)(const char *str) = &strdup;
	char		*(*handmade)(const char *str) = &ft_strdup;

	char *origin = (char*)mem_al(s);
	//char *origin2 = (char*)mem_al(s2);

	test_func(origin_f, origin, s, "privet_chelover");
	test_func(handmade, origin, s, "privet_chelover");
	printf("\n");

	test_func(origin_f, origin, s, "");
	test_func(handmade, origin, s, "");
	printf("\n");

	test_func(origin_f, origin, s, "h");
	test_func(handmade, origin, s, "h");
	printf("\n");

	test_func(origin_f, origin, s, "**()%^$\0%^#%^&");
	test_func(handmade, origin, s, "**()%^$\0%^#%^&");
	printf("\n");

	test_func(origin_f, origin, s, "\0\0\0\0\0\0");
	test_func(handmade, origin, s, "\0\0\0\0\0\0");
	printf("\n");

	//test_func(origin_f, NULL, s, "zzssddff");
	//test_func(handmade, NULL, s, "zzssddff");
	//printf("\n");
	return (0);
}
