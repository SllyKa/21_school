/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_template.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 16:38:04 by gbrandon          #+#    #+#             */
/*   Updated: 2018/11/27 12:53:50 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libc.h>
#include <stdlib.h>
#include "libft.h"
#include "libextra.h"
#include <errno.h>

void	errno_ch_and_pr(void)
{
	printf("%-15s%s: %i\n", "errno_res:", strerror(errno), errno);
	errno = 0;
}

void	s_print(char *str, size_t s)
{
	size_t i;

	i = 0;
	while (i < s)
	{
			printf("%c ", *str);
			i++;
			str++;
	}	
	printf("\n");
}

void    *mem_al(size_t n)
{
   void *a = malloc(n);
   return a;
}

void    mem_free(void *ptr)
{
	    free(ptr);
}

int     test_func(int (*f)(const char*), char *str1, size_t str_size,
		          char *txt1, int f_type)
{
	int	cmp_res;
	strcpy(str1, txt1);
	//strcpy(str2, txt2);

	cmp_res = f(str1);
	printf("%-15s%i\n","atoi_res:", cmp_res);

	if (f_type)
		printf("%-15s", "origin_res:");
	else
		printf("%-15s", "handmade_res:");
	s_print(str1, str_size);
	//bits(ptr_size, ptr);

	return (0);
}

int		main(void)
{
	extern int errno;
	size_t s = 50;
	//size_t s2 = 20;

	int		(*origin_f)(const char *ds) = &atoi;
	int		(*handmade)(const char *ds) = &ft_atoi;

	void *origin = mem_al(s);
	//void *origin2 = mem_al(s2);

	test_func(origin_f, origin, s,  "\n\n\n\n\n\n281219", 1);
	test_func(handmade, origin, s,  "\n\n\n\n\n\n281219", 0);
	printf("\n");

	test_func(origin_f, origin, s,  "privet_chenlovern", 1);
	test_func(handmade, origin, s,  "privet_chenlovern", 0);
	printf("\n");
	
	test_func(origin_f, origin, s,  "p187367rivetn_chelonver", 1);
	test_func(handmade, origin, s,  "p187367rivetn_chelonver", 0);
	printf("\n");

	test_func(origin_f, origin, s,  "     +34767", 1);
	test_func(handmade, origin, s,  "     +34767", 0);
	printf("\n");

	test_func(origin_f, origin, s,  "     -12987", 1);
	test_func(handmade, origin, s,  "     -12987", 0);
	printf("\n");

	test_func(origin_f, origin, s,  "\t\t\t\t++++752", 1);
	test_func(handmade, origin, s,  "\t\t\t\t++++752", 0);
	printf("\n");

	test_func(origin_f, origin, s,  "\0", 1);
	test_func(handmade, origin, s,  "\0", 0);
	printf("\n");

	test_func(origin_f, origin, s,  "", 1);
	test_func(handmade, origin, s,  "", 0);
	printf("\n");

	test_func(origin_f, origin, s,  "\r\r\r\r---67hgje", 1);
	test_func(handmade, origin, s,  "\r\r\r\r---67hgje", 0);
	printf("\n");

	test_func(origin_f, origin, s,  "    +-8723", 1);
	test_func(handmade, origin, s,  "    +-8723", 0);
	printf("\n");

	test_func(origin_f, origin, s,  "\f\f\f-6378fgf", 1);
	test_func(handmade, origin, s,  "\f\f\f-6378fgf", 0);
	printf("\n");

	test_func(origin_f, origin, s,  "   78945\n\f\f\f323", 1);
	test_func(handmade, origin, s,  "   78945\n\f\f\f323", 0);
	printf("\n");

	test_func(origin_f, origin, s,  "\r\f\v\t\n 76790", 1);
	test_func(handmade, origin, s,  "\r\f\v\t\n 76790", 0);
	printf("\n");

	test_func(origin_f, origin, s,  "-1+2-3+56", 1);
	test_func(handmade, origin, s,  "-1+2-3+56", 0);
	printf("\n");

	test_func(origin_f, origin, s,  "+765gg44", 1);
	test_func(handmade, origin, s,  "+765t55", 0);
	printf("\n");

	//test_func(origin_f, NULL, s, , 0, "privet_chelover", "poka_men");
	//test_func(handmade, NULL, s, , 0, "privet_chelover", "poka_men");
	//printf("\n");

	test_func(origin_f, origin, s,  "00000000001", 1);
	test_func(handmade, origin, s,  "00000000001", 0);
	printf("\n");

	//test_func(origin_f, origin, s, , -10, "privet_chelover", "poka_men");
	//test_func(handmade, origin, s, , -10, "privet_chelover", "poka_men");
	//printf("\n");
	
	test_func(origin_f, origin, s,  "-0000000", 1);
	test_func(handmade, origin, s,  "-0000000", 0);
	printf("\n");
	
	test_func(origin_f, origin, s,  "\n-2147483648",1);
	test_func(handmade, origin, s,  "\n-2147483648", 0);
	printf("\n");

	test_func(origin_f, origin, s,  " +2147483647", 1);
	test_func(handmade, origin, s,  " +2147483647", 0);
	printf("\n");

	test_func(origin_f, origin, s,  "    f1", 1);
	test_func(handmade, origin, s,  "    f1", 0);
	printf("\n");

	test_func(origin_f, origin, s,  " 2147483648", 1);
	test_func(handmade, origin, s,  " 2147483648", 0);
	printf("\n");

	test_func(origin_f, origin, s, "   +gg55", 1);
	test_func(handmade, origin, s, "   +gg55", 0);
	printf("\n");

	test_func(origin_f, origin, s, "  \n -gg67", 1);
	test_func(handmade, origin, s, "  \n -gg67", 0);
	printf("\n");

	test_func(origin_f, origin, s, "  \055760-", 1);
	test_func(handmade, origin, s, "  \055760-", 0);
	printf("\n");

	test_func(origin_f, origin, s, "999999999999", 1);
	test_func(handmade, origin, s, "999999999999", 0);
	printf("\n");

	errno_ch_and_pr();
	test_func(origin_f, origin, s, "92233720368547758101", 1);
	errno_ch_and_pr();
	test_func(handmade, origin, s, "92233720368547758101", 0);
	errno_ch_and_pr();
	printf("\n");

	errno_ch_and_pr();
	test_func(origin_f, origin, s, "-9223372036854775808", 1);
	errno_ch_and_pr();
	test_func(handmade, origin, s, "-9223372036854775808", 0);
	errno_ch_and_pr();
	printf("\n");

	errno_ch_and_pr();
	test_func(origin_f, origin, s, "-9223372036854775808987", 1);
	errno_ch_and_pr();
	test_func(handmade, origin, s, "-9223372036854775808987", 0);
	errno_ch_and_pr();
	printf("\n");

	errno_ch_and_pr();
	test_func(origin_f, origin, s, "922337203685477580898710", 1);
	errno_ch_and_pr();
	test_func(handmade, origin, s, "922337203685477580898710", 0);
	errno_ch_and_pr();
	printf("\n");

	test_func(origin_f, origin, s, " 00254", 1);
	test_func(handmade, origin, s, " 00254", 0);
	printf("\n");
	return (0);
}
