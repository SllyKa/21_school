/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_template.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbrandon <gbrandon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 16:38:04 by gbrandon          #+#    #+#             */
/*   Updated: 2018/12/06 17:00:25 by gbrandon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libc.h>
#include <stdlib.h>
#include "libft.h"
#include "libextra.h"

void	s_print(void *ptr, size_t s)
{
	size_t i;

	i = 0;
	while (i < s)
	{
			printf("%c ", *((char*)ptr));
			i++;
			ptr++;
	}	
	printf("\n");
}

void    *mem_al(size_t n)
{
   void *a = malloc(n);
   return a;
}

void    mem_free(void *ptr)
{
	    free(ptr);
}

int		test_func(void	*(*f)(void*, const void*, size_t n), void *ptr, size_t ptr_size, void *ptr2,
		size_t number_of_bytes, char *str1, char* str2)
{
	strcpy((char*)ptr, str1);
	strcpy((char*)ptr2, str2);

	ptr = f(ptr, ptr2, number_of_bytes);

	s_print(ptr, ptr_size);
	bits(ptr_size, ptr);
	printf("\n");

	return (0);
}

int		main(void)
{
	size_t s = 15;
	size_t s2 = 20;

	void	*(*origin_f)(void *dst, const void *src, size_t n) = &memcpy;
	void	*(*handmade)(void *dst, const void *src, size_t n) = &ft_memcpy;

	void *origin = mem_al(s);
	void *origin2 = mem_al(s2);

	test_func(origin_f, origin, s, origin2, 10, "privet_chelover", "poka_men");
	test_func(handmade, origin, s, origin2, 10, "privet_chelover", "poka_men");
	printf("\n");

	test_func(origin_f, origin, s, origin2, 0, "privet_chelover", "poka_men");
	test_func(handmade, origin, s, origin2, 0, "privet_chelover", "poka_men");
	printf("\n");
	
	//test_func(origin_f, NULL, s, origin2, 0, "privet_chelover", "poka_men");
	//test_func(handmade, NULL, s, origin2, 0, "privet_chelover", "poka_men");
	//printf("\n");

	test_func(origin_f, origin, s, origin2, 120, "privet_chelover", "poka_men");
	test_func(handmade, origin, s, origin2, 120, "privet_chelover", "poka_men");
	printf("\n");

	//test_func(origin_f, origin, s, origin2, -10, "privet_chelover", "poka_men");
	//test_func(handmade, origin, s, origin2, -10, "privet_chelover", "poka_men");
	//printf("\n");
	
	test_func(origin_f, origin, s, origin2, 14, "privet_chelover", "poka_men");
	test_func(handmade, origin, s, origin2, 14, "privet_chelover", "poka_men");
	printf("\n");

	test_func(origin_f, origin, s, origin2, 14, "privet_chelover", "poka\257_men");
	test_func(handmade, origin, s, origin2, 14, "privet_chelover", "poka\257_men");
	printf("\n");

	//printf("pointer: %p\n", origin_f(NULL, NULL, 10));
	//printf("pointer: %p\n", handmade(NULL, NULL, 10));
	return (0);
}
